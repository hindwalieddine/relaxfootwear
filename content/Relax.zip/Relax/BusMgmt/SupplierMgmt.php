<?php
include 'DataMgmt\SupplierDbMgmt.php';

class Supplier {
	private $no;
	private $name;
	private $phone;
	private $mobile;
	private $add;
	private $note;
	
	public function __construct($num, $nom, $tel, $mobile, $a , $ n){
		$this->no     = $num;
		$this->name   = $nom;
		$this->phone  = $tel;
		$this->mobile = $mobile;
		$this->add    = $a;
		$this->note   = $n;
	}
	
	public function printObject(){
		echo $this->no." ";
		echo $this->name." ";
		echo $this->phone." ";
		echo $this->mobile." ";
		echo $this->add." ";
		echo $this->note." ";		
	}
	
	public function getNum() { return $this->no; }
	public function getNum() { return $this->name; }
	public function getAddress() { return $this->phone; }
	public function getNum() { return $this->mobile; }
	public function getAddress() { return $this->add; }
	public function getAddress() { return $this->note; }
	
	public static function get($uid){
		if (SupplierDb::getSupplier($uid, $nom, $tel, $mobile, $a, $n)){
			$supp = new Supplier($n,$nom,$tel,$mobile,$a,$a);
		} else {
			$supp = null;
		}
		return $supp;
	}
}

/*
Class OrderLine {
	private $codep;
	private $qty;

	public function __construct($cp, $q){
		$this->codep = $cp;
		$this->qty   = $q;
	}
	
	public function printObject(){
		echo $this->codep." ";echo "<br>";
		echo $this->qty." ";echo "<br>";
	}
	
	public function getCodeProduit()  { return $this->codep;    }
	public function getQty() { return $this->qty; }
	
}

Class Order {
	private $no;
	private $dateo;

	public function __construct($num, $d){
		$this->no     = $num;
		$this->dateo = $d;
	}
	
	public function printObject(){
		echo $this->no." ";echo "<br>";
		echo $this->dateo." ";echo "<br>";
	}
	
	public function getNum()  { return $this->no;    }
	public function getDate() { return $this->dateo; }
	
	public static function createOrder($cid){
		OrderDb::createOrder($cid, $ordnum, $d);
		$o = new Order ($ordnum, $d);
		return $o;
	}
	
	public static function existOrder($cid, &$ord){
		$exist = OrderDb::existOrder($cid, $ordnum, $d); 
		if ($exist) $ord = new Order ($ordnum, $d);
		return $exist;
	}
	
	public function initListOrderLines(){
		OrderDb::initListOrderLines($this->no);
	}
	
	public function getNextOrderLine(&$ol){
		$ol = NULL;
		$next = false;
		if (OrderDb::getNextOrderLine($cp,$q)){
			$ol = new OrderLine($cp,$q);
			$next = true;
		}
		return $next;
	}
	
	public function existOrderLine($cp){
		return OrderDb::existOrderLine($cp,$this->no);
	}
	
	public function updateOrderLine($cp, $qt){
		return OrderDb::updateOrderLine($cp,$qt,$this->no);
	}

	public function addOrderLine($cp, $qt){
		return OrderDb::addOrderLine($cp,$qt,$this->no);
		
	}
	public function deleteOrderLine($cp){
		return OrderDb::deleteOrderLine($cp,$this->no);
	}

}


*/
?>