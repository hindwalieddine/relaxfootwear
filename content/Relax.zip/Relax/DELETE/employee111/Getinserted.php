<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$date=date('Y-m-d');

if(isset($_POST['submit'])){
$from=$_POST['fromdatetxt'];
$to=$_POST['todate'];
	if(($from==NULL)&&($to==NULL)){ 	?>
    <script language="javascript">
	alert("Please choose 2 dates");
	location = 'Getinserted.php';
	</script>
    <?php
	exit;
	}
	
header("Get_All_inserted_articles.php?from=$from&?to=$to");
//header("Get_All_inserted_articles.php");
}
?>

<html>  
<form name="GetInsertform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table align="center" >
          <tr>
            <td width="79">From date</td>
            <td width="88"><input type="text" size="10" name="fromdatetxt" value="<?php echo $date ?>"/></td>
          </tr>
          <tr>
            <td>To date</td>
            <td><input type="text" size="10" name="todate" value="<?php echo $date?>"/></td>
          </tr>
          <tr>
            <td align="center" colspan="2"><input type="submit" name="submit" value="Search" /></td>
          </tr>
        </table>
        



</form>
</html>