<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$quantity=1;
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	$diff1=($price1-$price2);
	if($price2>0){ $Cash=$price2; }
	elseif (($price2==0)||($price2==NULL)){$Cash=$price1; $price2=$price1; $diff1=0;}
	$supid=$plist[article_supplier_id];
	$suppresult=mysql_query("SELECT * FROM supplier WHERE supplier_id='$supid'") or die("error: ".mysql_error());
	if($plist1=mysql_fetch_assoc($suppresult)) {
	$suppname=$plist1[supplier_name];}

$json = array(array('field' => 'price',
'value' => $price1),
array('field' => 'price1',
'value' => $price2),
array('field' =>'diff1',
'value' => $diff1),
array('field' => 'Cash',
'value' => $Cash),
array('field' => 'quantity',
'value' => $quantity) //last item should have no comma
);
}
}
print json_encode($json);
?>