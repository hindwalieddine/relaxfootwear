<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$quantitya=1;
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	$diff2=($price1-$price2);
	if($price2>0){ $Casha=$price2; }
	elseif (($price2==0)||($price2==NULL)){$Casha=$price1; $price2=$price1; $diff2=0;}

$json = array(array('field' => 'pricea',
'value' => $price1),
array('field' => 'price1a',
'value' => $price2),
array('field' =>'diff2',
'value' => $diff2),
array('field' => 'Casha',
'value' => $Casha),
array('field' => 'quantitya',
'value' => $quantitya) //last item should have no comma
);
}
}
print json_encode($json);
?>

