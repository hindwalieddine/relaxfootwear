<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$quantityb=1;
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	$diff2=($price1-$price2);
	if($price2>0){ $Cashb=$price2; }
	elseif (($price2==0)||($price2==NULL)){$Cashb=$price1; $price2=$price1; $diff3=0;}

$json = array(array('field' => 'priceb',
'value' => $price1),
array('field' => 'price1b',
'value' => $price2),
array('field' =>'diff3',
'value' => $diff3),
array('field' => 'Cashb',
'value' => $Cashb),
array('field' => 'quantityb',
'value' => $quantityb) //last item should have no comma
);
}
}
print json_encode($json);
?>

