<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$quantityc=1;
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	$diff2=($price1-$price2);
	if($price2>0){ $Cashc=$price2; }
	elseif (($price2==0)||($price2==NULL)){$Cashc=$price1; $price2=$price1; $diff4=0;}

$json = array(array('field' => 'pricec',
'value' => $price1),
array('field' => 'price1c',
'value' => $price2),
array('field' =>'diff4',
'value' => $diff4),
array('field' => 'Cashc',
'value' => $Cashc),
array('field' => 'quantityc',
'value' => $quantityc) //last item should have no comma
);
}
}
print json_encode($json);
?>

