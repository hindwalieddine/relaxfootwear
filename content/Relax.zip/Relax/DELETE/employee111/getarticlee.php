<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$quantitye=1;
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	$diff2=($price1-$price2);
	if($price2>0){ $Cashe=$price2; }
	elseif (($price2==0)||($price2==NULL)){$Cashe=$price1; $price2=$price1; $diff6=0;}

$json = array(array('field' => 'pricee',
'value' => $price1),
array('field' => 'price1e',
'value' => $price2),
array('field' =>'diff6',
'value' => $diff6),
array('field' => 'Cashe',
'value' => $Cashe),
array('field' => 'quantitye',
'value' => $quantitye) //last item should have no comma
);
}
}
print json_encode($json);
?>

