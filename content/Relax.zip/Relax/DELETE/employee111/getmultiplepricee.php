<?php
include_once("../config/connect.php");

$qty=$_GET['qty'];
$price=$_GET['p'];
//echo $qty; echo "<br>";
//echo $p;
if (isset($qty)) {
	$Cashc=($qty*$price);
	
$json = array(array('field' => 'Cashe',
'value' => $Cashe) //last item should have no comma
);

}
print json_encode($json);
?>