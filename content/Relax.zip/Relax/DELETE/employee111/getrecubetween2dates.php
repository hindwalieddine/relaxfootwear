<?php
ob_start();
$from=$_GET['from'];
$to=$_GET['todate'];
echo $from;
echo "<br>";
echo $to;
echo "<br>";
	?>

<table align="center">
  <tr>
    <td>Serie 1</td>
    <td>18</td>
    <td>19</td>
    <td>20</td>
    <td>21</td>
    <td>22</td>
    <td>23</td>
    <td>24</td>
    <td>25</td>
    <td>26</td>
    <td></td>
  </tr>
  <tr>
    <td>Serie 2</td>
    <td>27</td>
    <td>28</td>
    <td>29</td>
    <td>30</td>
    <td>31</td>
    <td>32</td>
    <td>33</td>
    <td>34</td>
    <td>35</td>
    <td>36</td>
  </tr>
  <tr>
  <td>Serie 3/4/5</td>
  <td>35</td>
  <td>36</td>
  <td>37</td>
  <td>38</td>
  <td>39</td>
  <td>40</td>
  <td>41</td>
  <td>42</td>
  <td></td>
  <td></td>
  </tr>
  <?php
  require("Get_All_inserted_articles.php");
$query1=mysql_query("SELECT * FROM  `serie1` WHERE  `serie1_date` BETWEEN  \"$from\" AND  \"$to\" LIMIT 0 , 30 "); //echo $query; 
while($result1=mysql_fetch_array($query1)){
	?>
    <tr><td></td>
    <td><?php echo $result1['serie1_18'];?></td>
    <td><?php echo $result1['serie1_19'];?></td>
	<td><?php echo $result1['serie1_20'];?></td>
    <td><?php echo $result1['serie1_21'];?></td>
    <td><?php echo $result1['serie1_22'];?></td>
    <td><?php echo $result1['serie1_23'];?></td>
    <td><?php echo $result1['serie1_24'];?></td>
    <td><?php echo $result1['serie1_25'];?></td>
    <td><?php echo $result1['serie1_26'];?></td>
    <td></td>
       </tr>
    
    <?php
	
}
?>
</table>
