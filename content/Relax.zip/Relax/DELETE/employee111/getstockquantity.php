<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
	$qty1=0; $qty2=0; $qty3=0; $qty4=0; $qty5=0; $qty6=0; $qty7=0; $qty8=0; $qty9=0; $qty10=0; $qty11=0; $qty12=0; $qty13=0;
$result=mysql_query("SELECT * FROM inserted_article WHERE inserted_article='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$qty1=$qty1+$plist[qty1];
	$qty2=$qty2+$plist[qty2];
	$qty3=$qty3+$plist[qty3];
	$qty4=$qty4+$plist[qty4];
	$qty5=$qty5+$plist[qty5];
	$qty6=$qty6+$plist[qty6];
	$qty7=$qty7+$plist[qty7];
	$qty8=$qty8+$plist[qty8];
	$qty9=$qty9+$plist[qty9];
	$qty10=$qty10+$plist[qty10];
	$qty11=$qty12+$plist[qty11];
	$qty12=$qty12+$plist[qty12];
	$qty13=$qty13+$plist[qty13];
   

$json = array(array('field' => 'qty1',
'value' => $qty1),
array('field' => 'qty2',
'value' => $qty2),
array('field' => 'qty3',
'value' => $qty3),
array('field' => 'qty4',
'value' => $qty4),
array('field' => 'qty5',
'value' => $qty5),
array('field' => 'qty6',
'value' => $qty6),
array('field' => 'qty7',
'value' => $qty7),
array('field' => 'qty8',
'value' => $qty8),
array('field' => 'qty9',
'value' => $qty9),
array('field' => 'qty10',
'value' => $qty10),
array('field' => 'qty11',
'value' => $qty11),
array('field' => 'qty12',
'value' => $qty12),
array('field' => 'qty13',
'value' => $qty13)
 //last item should have no comma
);
}
}
print json_encode($json);
?>