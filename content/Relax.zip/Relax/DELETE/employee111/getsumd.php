<?php
include_once("../config/connect.php");

$qty=$_GET['qty'];
$id=$_GET['aID'];
if (isset($id)) {
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$price0=$plist[article_pur_price];
	$price1=$plist[article_sale_price];
	$price2=$plist[article_after_solde_price];
	
  if(($price2== 0) || ($price2==NULL)) {
	$json = array(array('field' => 'Cashd',
    'value' => $price1) );
		}
		elseif($price2>0){ 	
	 $json = array(array('field' => 'Cashd',
    'value' => $price2) );}

}
}
print json_encode($json);
?>