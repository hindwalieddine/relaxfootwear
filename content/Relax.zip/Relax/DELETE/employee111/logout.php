<?php

session_start();

// Détruit toutes les variables de session
$_SESSION = array();

if (isset($_COOKIE[session_start()])) {
    setcookie(session_start(), '', time()-42000, '/');
}

?>
<script language="javascript">
	//alert("You must fill all the required field ");
	location = '../index.php';
	</script>
    <?php
// Finalement, on détruit la session.
session_destroy();

?> 