<html>
<table width="826" align="center" bgcolor="#3399FF">
<tr><td width="98" height="30"><a href="home.php">Home</a></td>
<td width="262"><a href="vente.php">Vente</a></td>
<td width="165"><a href="recuRelax.php">Recu To Relax</a></td>
<td width="165"><a href="recuSolderie.php">Recu To Solderie</a></td>
<td width="165"><a href="recuDepot.php">Recu To Depot</a></td>
<td width="117"><a href="transfert.php">Transfer</a></td>
<td width="165"><a href="queries.php">Queries</a></td>
<td width="106"><a href="logout.php">Logout</a></td>

</tr>
</table>
</html>