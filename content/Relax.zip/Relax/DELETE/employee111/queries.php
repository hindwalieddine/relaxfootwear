<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");

?>