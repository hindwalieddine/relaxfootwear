<?php
ob_start();
require("../config/connect.php");
include_once("menu.php");
$datenow=date('Y-m-d');
//echo "datenow: ".$datenow; 

if(isset($_POST['submit'])){
$article=$_POST[GetArticles];
$selecteddate=$_POST[datetxt];
$totalquantity=$_POST[qtytxt];
$qtya=$_POST[qtya];
$qtyb=$_POST[qtyb];
$qtyc=$_POST[qtyc];
$qtyd=$_POST[qtyd];
$qtye=$_POST[qtye];
$qtyf=$_POST[qtyf];
$qtyg=$_POST[qtyg];
$qtyh=$_POST[qtyh];
$qtyi=$_POST[qtyi];
$qtyj=$_POST[qtyj];
$qtyk=$_POST[qtyk];
$qtyl=$_POST[qtyl];
$qtym=$_POST[qtym];
$qty1=$_POST[qty1];
$qty2=$_POST[qty2];
$qty3=$_POST[qty3];
$qty4=$_POST[qty4];
$qty5=$_POST[qty5];
$qty6=$_POST[qty6];
$qty7=$_POST[qty7];
$qty8=$_POST[qty8];
$qty9=$_POST[qty9];
$qty10=$_POST[qty10];
$qty11=$_POST[qty11];
$qty12=$_POST[qty12];
$qty13=$_POST[qty13];
//echo "g ".$qtyg; //10  mazbouta  7
//echo "j ".$qtyj; //null mazbouta 10
//echo "date: ".$selecteddate;
 

if(($qtya==NULL)&&($qtyb==NULL)&&($qtyc==NULL)&&($qtyd==NULL)&&($qtye==NULL)&&($qtyf==NULL)&&($qtyg==NULL)&&($qtyh==NULL)&&($qtyi==NULL)&&($qtyj==NULL)&&($qtyk==NULL)&&($qtyl==NULL)&&($qtym==NULL)&&($totalquantity==NULL)&&($article==NULL)){
	?>
		<script language="javascript">
	alert("Please fill the fielleds");
	location = 'recuRelax.php';
	</script>
    <?php
	exit;
                                                          }
				 
if(($totalquantity==NULL)||($article==NULL)||($selecteddate==NULL)){
		?>
		<script language="javascript">
	alert("Please fill the QTY & ARTICLE");
	location = 'recuRelax.php';
	</script>
    <?php
	exit;
	                                                               }
// Check to see if the article is already inserted or not!

	$count=mysql_query("SELECT COUNT( * ) AS nb
FROM  `article` 
WHERE  `article`.`article_id` =  '$article' LIMIT 1;");
$result=mysql_fetch_array($count);
$nb=$result['nb'];
//echo "nb: ".$nb; echo "<br>";
if($nb==0){?>
<script language="javascript">
	alert("You Need to create the article before inserting");
	location = 'recuRelax.php';
	</script>
<?php
	exit;
}

//$query="SELECT COUNT( * ) AS n FROM  `inserted_article` WHERE  `inserted_article` =  '$article' AND `inserted_date` = '$selecteddate';"; echo $query;exit;
	$count=mysql_query("SELECT COUNT( * ) AS n
FROM  `inserted_article` 
WHERE  `inserted_article` =  '$article'
AND `inserted_date` = '$selecteddate' LIMIT 1;");
$result=mysql_fetch_array($count);
$n=$result['n'];
//echo "nb: ".$nb; echo "<br>";
if($n>0){?>
<script language="javascript">
	alert("You did insert this article in this date");
	location = 'recuRelax2.php?id=<?php echo $article;?>&d=<?php echo selecteddate;?>&q=<?php echo $totalquantity;?>&q1=<?php echo $qtya;?>&q2=<?php echo $qtyb;?>&q3=<?php echo $qtyc;?>&q4=<?php echo $qtyd;?>&q5=<?php echo $qtye;?>&q6=<?php echo $qtyf;?>&q7=<?php echo $qtyg;?>&q8=<?php echo $qtyh;?>&q9=<?php echo $qtyi;?>&q10=<?php echo $qtyj;?>&q11=<?php echo $qtyk;?>&q12=<?php echo $qtyl;?>&q13=<?php echo $qtym;?>&qty1=<?php echo $qty1;?>&qty2=<?php echo $qty2;?>&qty3=<?php echo $qty3;?>&qty4=<?php echo $qty4;?>&qty5=<?php echo $qty5;?>&qty6=<?php echo $qty6;?>&qty7=<?php echo $qty7;?>&qty8=<?php echo $qty8;?>&qty9=<?php echo $qty9;?>&qty10=<?php echo $qty10;?>&qty11=<?php echo $qty11;?>&qty12=<?php echo $qty12;?>&qty13=<?php echo $qty13;?>';
	</script>
<?php
	exit;
}

$tot=($qtya+$qtyb+$qtyc+$qtyd+$qtye+$qtyf+$qtyg+$qtyh+$qtyi+$qtyj+$qtyk+$qtyl+$qtym);
//echo "tot:".$tot;
if($tot!=$totalquantity){
	?>
	<script language="javascript">
	alert("The numbers that you have inserted did not match the total quantity!");
	location = 'recuRelax2.php?id=<?php echo $article;?>&d=<?php echo selecteddate;?>&q=<?php echo $totalquantity;?>&q1=<?php echo $qtya;?>&q2=<?php echo $qtyb;?>&q3=<?php echo $qtyc;?>&q4=<?php echo $qtyd;?>&q5=<?php echo $qtye;?>&q6=<?php echo $qtyf;?>&q7=<?php echo $qtyg;?>&q8=<?php echo $qtyh;?>&q9=<?php echo $qtyi;?>&q10=<?php echo $qtyj;?>&q11=<?php echo $qtyk;?>&q12=<?php echo $qtyl;?>&q13=<?php echo $qtym;?>&qty1=<?php echo $qty1;?>&qty2=<?php echo $qty2;?>&qty3=<?php echo $qty3;?>&qty4=<?php echo $qty4;?>&qty5=<?php echo $qty5;?>&qty6=<?php echo $qty6;?>&qty7=<?php echo $qty7;?>&qty8=<?php echo $qty8;?>&qty9=<?php echo $qty9;?>&qty10=<?php echo $qty10;?>&qty11=<?php echo $qty11;?>&qty12=<?php echo $qty12;?>&qty13=<?php echo $qty13;?>';
	</script>
<?php
	exit;
	
	}
	
	else{

$Insertquery=mysql_query("INSERT INTO  `inserted_article` (  `inserted_id` ,  `inserted_article` ,  `inserted_date` ,  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` ) 
VALUES (NULL ,  '$article',  '$selecteddate',  '$qtya',  '$qtyb',  '$qtyc',  '$qtyd',  '$qtye',  '$qtyf',  '$qtyg',  '$qtyh',  '$qtyi',  '$qtyj',  '$qtyk',  '$qtyl',  '$qtym')");
header("recuRelax.php");
		
}
}
?>

<html>

<head>
<!-- Auto Tab  -->
<script type="text/javascript" src="js/jquery.autotab.js"></script>
<!-- Get the information of the size quantity exist in the stock   (from the employee)-->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<!-- For Calendar -->
<script language="JavaScript" src="js/ts_picker.js"></script>
<!-- Calcule de la somme -->
<script src="js/jquery.min.js"></script>
</head>



<body onLoad="document.Recuform.qtytxt.focus()">
<form name="Recuform" action="<?php $_SERVER[PHP_SELF]; ?>" method="post">
  <table align="center">
    <tr>
      <td> Date:
        <input type="text" name="datetxt" value="<?php echo $datenow; ?>" />
        <!-- Input of the date 
<input type="Text" name="timestamp" value="">
<a href="javascript:show_calendar('document.Recuform.timestamp', document.Recuform.timestamp.value);"><img src="images/cal.gif" width="16" height="16" border="0" alt="Click Here to Pick up the timestamp"></a>
<!-- End input of the date --></td>
      <td> Quantity
        <input name="qtytxt" id="qtytxt" size="5" maxlength="4">
    </tr>
  </table>
  <table width="497" border="1" cellpadding="0" cellspacing="0" align="center">
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 1</td>
      <td width="35">18</td>
      <td width="35	">19</td>
      <td width="35">20</td>
      <td width="35">21</td>
      <td width="35">22</td>
      <td width="35">23</td>
      <td width="35">24</td>
      <td width="35">25</td>
      <td width="35">26</td>
      <td width="35">27</td>
      <td width="35">28</td>
      <td width="35">29</td>
      <td width="35">30</td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 2</td>
      <td width="35">25</td>
      <td width="35">26</td>
      <td width="35">27</td>
      <td width="35">28</td>
      <td width="35">29</td>
      <td width="35">30</td>
      <td width="35">31</td>
      <td width="35">32</td>
      <td width="35">33</td>
      <td width="35">34</td>
      <td width="35">35</td>
      <td width="35">36</td>
      <td width="35">37</td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie3/4/5</td>
      <td width="35">35</td>
      <td width="35">36</td>
      <td width="35">37</td>
      <td width="35">38</td>
      <td width="35">39</td>
      <td width="35">40</td>
      <td width="35">41</td>
      <td width="35">42</td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 7</td>
      <td width="35">39</td>
      <td width="35">40</td>
      <td width="35">41</td>
      <td width="35">41.5</td>
      <td width="35">42</td>
      <td width="35">42.5</td>
      <td width="35">43</td>
      <td width="35">43.5</td>
      <td width="35">44</td>
      <td width="35">45</td>
      <td width="35">46</td>
      <td width="35">47</td>
      <td width="35">48</td>
    </tr>
    <tr>
      <td width="77"><input type="text" name="GetArticles" id="GetArticles" size="5" maxlength="7" onKeyUp="checkArticle()"></td>
      <td width="35"><input type="text" name="qtya" id="qtya" size="1"></td>
      <td width="35"><input type="text" name="qtyb" id="qtyb" size="1"></td>
      <td width="35"><input type="text" name="qtyc" id="qtyc" size="1"></td>
      <td width="35"><input type="text" name="qtyd" id="qtyd" size="1"></td>
      <td width="35"><input type="text" name="qtye" id="qtye" size="1"></td>
      <td width="35"><input type="text" name="qtyf" id="qtyf" size="1"></td>
      <td width="35"><input type="text" name="qtyg" id="qtyg" size="1"></td>
      <td width="35"><input type="text" name="qtyh" id="qtyh" size="1"></td>
      <td width="35"><input type="text" name="qtyi" id="qtyi" size="1"></td>
      <td width="35"><input type="text" name="qtyj" id="qtyj" size="1"></td>
      <td width="35"><input type="text" name="qtyk" id="qtyk" size="1"></td>
      <td width="35"><input type="text" name="qtyl" id="qtyl" size="1"></td>
      <td width="35"><input type="text" name="qtym" id="qtym" size="1"></td>
    </tr>
    <tr bgcolor="#66CCCC">
      <td width="77">In Stock </td>
      <td width="35"><input type="text" name="qty1" id="qty1" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty2" id="qty2" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty3" id="qty3" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty4" id="qty4" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty5" id="qty5" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty6" id="qty6" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty7" id="qty7" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty8" id="qty8" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty9" id="qty9" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty10" id="qty10" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty11" id="qty11" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty12" id="qty12" size="1" readonly="readonly"></td>
      <td width="35"><input type="text" name="qty13" id="qty13" size="1" readonly="readonly"></td>
    </tr>
  </table>
  <input type="submit" id="submit" name="submit" value="Save">
</form>
<div id="images"></div>

<!--  from 1st article to 1st size  --> 
<script type="text/javascript">
$(document).ready(function() {
    $('#GetArticles, #qtya').autotab_magic().autotab_filter('numeric');
});
</script> 

<script type="text/javascript">
$("#GetArticles").bind("change", function(e){
$.getJSON("getstockquantity.php?aID=" + $("#GetArticles").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "qty1") {
$("#qty1").val(item.value);
} else if (item.field == "qty2") {
$("#qty2").val(item.value);
} else if (item.field == "qty3") {
$("#qty3").val(item.value);
} else if (item.field == "qty4") {
$("#qty4").val(item.value);
} else if (item.field == "qty5") {
$("#qty5").val(item.value);
} else if (item.field == "qty6") {
$("#qty6").val(item.value);
} else if (item.field == "qty7") {
$("#qty7").val(item.value);
} else if (item.field == "qty8") {
$("#qty8").val(item.value);
} else if (item.field == "qty9") {
$("#qty9").val(item.value);
} else if (item.field == "qty10") {
$("#qty10").val(item.value);
} else if (item.field == "qty11") {
$("#qty11").val(item.value);
} else if (item.field == "qty12") {
$("#qty12").val(item.value);
} else if (item.field == "qty13") {
$("#qty13").val(item.value);
} 
});
});
});
</script>


</body>
</html>
