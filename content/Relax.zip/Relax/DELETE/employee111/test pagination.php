<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$date=date('Y-m-d');
$from=$_POST['fromdatetxt'];
$to=$_POST['todate'];
//echo $from; echo "<br>"; echo $to;
?>
<html>
<form name="GetInsertform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table width="741" height="307" align="center" >
    <tr>
      <td width="187" valign="top"><table width="183" border="0" align="left">
          <tr>
            <td width="79">From date</td>
            <td width="88"><input type="text" size="10" name="fromdatetxt" value="<?php echo $date ?>"/></td>
          </tr>
          <tr>
            <td>To date</td>
            <td><input type="text" size="10" name="todate" value="<?php echo $date?>"/></td>
          </tr>
          <tr>
            <td align="center" colspan="2"><input type="submit" name="submit" value="Search" /></td>
          </tr>
        </table></td>
      <td width="542"><table width="446" border="1" cellpadding="0" cellspacing="0" align="center">
          <tr bgcolor="#66CCCC" align="center">
            <td width="76">Serie 1</td>
            <td width="30">18</td>
            <td width="30">19</td>
            <td width="30">20</td>
            <td width="30">21</td>
            <td width="30">22</td>
            <td width="30">23</td>
            <td width="30">24</td>
            <td width="30">25</td>
            <td width="30">26</td>
            <td width="30">27</td>
            <td width="30">28</td>
            <td width="30">29</td>
            <td width="30">30</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="76">Serie 2</td>
            <td width="30">25</td>
            <td width="30">26</td>
            <td width="30">27</td>
            <td width="30">28</td>
            <td width="30">29</td>
            <td width="30">30</td>
            <td width="30">31</td>
            <td width="30">32</td>
            <td width="30">33</td>
            <td width="30">34</td>
            <td width="30">35</td>
            <td width="30">36</td>
            <td width="30">37</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td>Serie 3/4/5</td>
            <td width="30">35</td>
            <td width="30">36</td>
            <td width="30">37</td>
            <td width="30">38</td>
            <td width="30">39</td>
            <td width="30">40</td>
            <td width="30">41</td>
            <td width="30">42</td>
            <td width="30"></td>
            <td width="30"></td>
            <td width="30"></td>
            <td width="30"></td>
            <td width="30"></td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td>Serie 7</td>
            <td width="30">39</td>
            <td width="30">40</td>
            <td width="30">41</td>
            <td width="30">41.5</td>
            <td width="30">42</td>
            <td width="30">42.5</td>
            <td width="30">43</td>
            <td width="30">43.5</td>
            <td width="30">44</td>
            <td width="30">45</td>
            <td width="30">46</td>
            <td width="30">47</td>
            <td width="30">48</td>
          </tr>
          <?php
$DeleteRowsFromTemp=mysql_query("TRUNCATE TABLE  `temp`");
$query1=mysql_query("SELECT * FROM  `serie1` WHERE  `serie1_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie1_article` LIMIT 0 , 30 ");
    
while($result1=mysql_fetch_array($query1)){
	$article=$result1['serie1_article'];
	$date=$result1['serie1_date'];
	$qty18=$result1['serie1_18'];
	$qty19=$result1['serie1_19'];
	$qty20=$result1['serie1_20'];
	$qty21=$result1['serie1_21'];
	$qty22=$result1['serie1_22'];
	$qty23=$result1['serie1_23'];
	$qty24=$result1['serie1_24'];
	$qty25=$result1['serie1_25'];
	$qty26=$result1['serie1_26'];
	$qty27=$result1['serie1_27'];
	$qty28=$result1['serie1_28'];
	$qty29=$result1['serie1_29'];
	$qty30=$result1['serie1_30'];
$queryInsert1=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '$qty25',  '$qty26',  '$qty27',  '$qty28',  '$qty29',  '$qty30'
)");
 }
 
//get all the serie2 
$query2=mysql_query("SELECT * FROM  `serie2` WHERE  `serie2_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie2_article` LIMIT 0 , 30 "); 
    
while($result2=mysql_fetch_array($query2)){
	$article=$result2['serie2_article'];
	$date=$result2['serie2_date'];
	$qty18=$result2['serie2_25'];
	$qty19=$result2['serie2_26'];
	$qty20=$result2['serie2_27'];
	$qty21=$result2['serie2_28'];
	$qty22=$result2['serie2_29'];
	$qty23=$result2['serie2_30'];
	$qty24=$result2['serie2_31'];
	$qty25=$result2['serie2_32'];
	$qty26=$result2['serie2_33'];
	$qty27=$result2['serie2_34'];
	$qty28=$result2['serie2_35'];
	$qty29=$result2['serie2_36'];
	$qty30=$result2['serie2_37'];
$queryInsert2=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '$qty25',  '$qty26',  '$qty27',  '$qty28',  '$qty29',  '$qty30'
)");

 } 
 
//get all the serie3
$query3=mysql_query("SELECT * FROM  `serie3` WHERE  `serie3_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie3_article` LIMIT 0 , 30 "); 
    
while($result3=mysql_fetch_array($query3)){
	$article=$result3['serie3_article'];
	$date=$result3['serie3_date'];
	$qty18=$result3['serie3_35'];
	$qty19=$result3['serie3_36'];
	$qty20=$result3['serie3_37'];
	$qty21=$result3['serie3_38'];
	$qty22=$result3['serie3_39'];
	$qty23=$result3['serie3_40'];
	$qty24=$result3['serie3_41'];
$queryInsert3=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '',  '',  '',  '',  '',  '')");
	 } 
	 
//get all the serie4
$query4=mysql_query("SELECT * FROM  `serie4` WHERE  `serie4_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie4_article` LIMIT 0 , 30 "); 
    
while($result4=mysql_fetch_array($query4)){
	$article=$result4['serie4_article'];
	$date=$result4['serie4_date'];
	$qty18=$result4['serie4_35'];
	$qty19=$result4['serie4_36'];
	$qty20=$result4['serie4_37'];
	$qty21=$result4['serie4_38'];
	$qty22=$result4['serie4_39'];
	$qty23=$result4['serie4_40'];
	$qty24=$result4['serie4_41'];
	$qty25=$result4['serie4_42'];
$queryInsert4=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '$qty25',  '',  '',  '',  '',  '')");
	
  } 
  
//get all the serie5
$query5=mysql_query("SELECT * FROM  `serie5` WHERE  `serie5_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie5_article` LIMIT 0 , 30 "); 
    
while($result5=mysql_fetch_array($query5)){
	$article=$result5['serie5_article'];
	$date=$result5['serie5_date'];
	$qty18=$result5['serie5_35'];
	$qty19=$result5['serie5_36'];
	$qty20=$result5['serie5_37'];
	$qty21=$result5['serie5_38'];
	$qty22=$result5['serie5_39'];
	$qty23=$result5['serie5_40'];
	$qty24=$result5['serie5_41'];
	$qty25=$result5['serie5_42'];
$queryInsert5=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '$qty25',  '',  '',  '',  '',  '')");
}

//get all the serie6
$query6=mysql_query("SELECT * FROM  `serie6_accessoires` WHERE  `serie6_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie6_article` LIMIT 0 , 30 "); 
    
while($result6=mysql_fetch_array($query6)){
	$article=$result6['serie6_article'];
	$date=$result6['serie6_date'];
	$qty18=$result6['serie6_qty'];
$queryInsert6=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '')");
 } 
//get all the serie7
$query7=mysql_query("SELECT * FROM  `serie7` WHERE  `serie7_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie7_article` LIMIT 0 , 30 "); 
    
while($result7=mysql_fetch_array($query7)){

	$article=$result7['serie7_article'];
	$date=$result7['serie7_date'];
	$qty18=$result7['serie7_39'];
	$qty19=$result7['serie7_40'];
	$qty20=$result7['serie7_41'];
	$qty21=$result7['serie7_41.5'];
	$qty22=$result7['serie7_42'];
	$qty23=$result7['serie7_42.5'];
	$qty24=$result7['serie7_43'];
	$qty25=$result7['serie7_43.5'];
	$qty26=$result7['serie7_44'];
	$qty27=$result7['serie7_45'];
	$qty28=$result7['serie7_46'];
	$qty29=$result7['serie7_47'];
	$qty30=$result7['serie7_48'];
$queryInsert7=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '$qty19',  '$qty20',  '$qty21',  '$qty22',  '$qty23',  '$qty24',  '$qty25',  '$qty26',  '$qty27',  '$qty28',  '$qty29',  '$qty30')");

        }
        
//get all the serie8
$query8=mysql_query("SELECT * FROM  `serie8_bags` WHERE  `serie8_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie8_article` LIMIT 0 , 30 "); 
    
while($result8=mysql_fetch_array($query8)){
	$article=$result8['serie8_article'];
	$date=$result8['serie8_date'];
	$qty18=$result8['serie8_qty'];
$queryInsert6=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '')");


}
//get all the serie8
$query9=mysql_query("SELECT * FROM  `serie9_bas` WHERE  `serie9_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie9_article` LIMIT 0 , 30 "); 
    
while($result9=mysql_fetch_array($query9)){
	$article=$result9['serie9_article'];
	$date=$result9['serie9_date'];
	$qty18=$result9['serie9_qty'];
$queryInsert6=mysql_query("INSERT INTO  `temp` (  `temp_id` ,  `temp_article` ,  `temp_date` ,  `temp_qty1` ,  `temp_qty2` ,  `temp_qty3` ,  `temp_qty4` ,  `temp_qty5` ,  `temp_qty6` ,  `temp_qty7` ,  `temp_qty8` ,  `temp_qty9` , `temp_qty10` ,  `temp_qty11` ,  `temp_qty12` ,  `temp_qty13` ) 
VALUES (
NULL ,  '$article',  '$date',  '$qty18',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '')");

	} 
	  //Pour les pagination du page
	  $messagesParPage=22; //Nous allons afficher 5 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM temp "); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire
	
$queryfinal=mysql_query("SELECT * FROM  `temp` ORDER BY  `temp_article` LIMIT".$premiereEntree.", ".$messagesParPage." ");

 while($Finalresult=mysql_fetch_array($queryfinal)){ ?>
          <tr align="center">
            <td><?php echo $Finalresult['temp_article'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty1'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty2'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty3'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty4'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty5'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty6'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty7'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty8'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty9'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty10'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty11'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty12'];?></td>
            <td width="30"><?php echo $Finalresult['temp_qty13'];?></td>
          </tr>
<?php
	} ?>   
    
    
        </table>
              <?php
//pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="Get_All_inserted_articles.php?page='.$i.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
?>

        
        </td>
    </tr>

    <?php
	if(($from==NULL)&&($to==NULL)){ 	?>
    <script language="javascript">
	alert("Please choose 2 dates");
	//location = 'insert_supplier.php';
	</script>
    <?php
	exit;
	}
	?>
  </table>
  
</form>
</html>