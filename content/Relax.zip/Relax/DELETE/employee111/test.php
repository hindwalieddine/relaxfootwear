<?php
ob_start();
require("../config/connect.php");
$query=mysql_query("SELECT * FROM  `article` ORDER BY `article`.`article_id` ASC LIMIT 0 , 30");
echo $ReadArticles;
while($result=mysql_query($query)){ 
echo "1111";
echo $result['article_id'];echo "<br>";

}
?>