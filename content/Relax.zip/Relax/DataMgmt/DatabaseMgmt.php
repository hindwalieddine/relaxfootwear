<?php

Class Database {

	private static $link;
	private static $connected = 0;

	static public function connect() {
				
		// Connexion MySQL
		if (Database::$connected == 0) {
			Database::$link = mysql_connect('admin', 'root', '');
			if (!Database::$link) {
			    echo 'Connexion impossible à mysql';
			    exit;
			}
			
			// Connexion Base
			
			if (!mysql_select_db('relax', Database::$link)) {
			    echo 'Sélection de base de données impossible'; 
			    exit;
			}
			Database::$connected = 1;
		}		
	}
	
	static public function getLink() { return Database::$link; }
}

?>