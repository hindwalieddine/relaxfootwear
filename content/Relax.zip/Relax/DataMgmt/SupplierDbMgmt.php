<?php
include_once 'DataMgmt\DatabaseMgmt.php';

Class SupplierDb {

	private static $lastresult;
	
	static public function getSupplier($uid, &$custnum, &$custaddress){
		Database::connect();
		$sql = "SELECT * FROM supplier where supplier_id = '".$uid."'";
		CustomerDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!CustomerDb::$lastresult) {
			echo $sql;
			echo "Customer DB Mgmt\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
		
		$exist = false;
		$row = mysql_fetch_assoc(SupplierDb::$lastresult);
		if ($row){
			$suppnum  = $row['supplier_id'];
			$suppname  = $row['supplier_name'];
			$suppphone  = $row['supplier_phone'];
			$suppmobile  = $row['supplier_mobile'];
			$suppaddress  = $row['supplier_address'];
			$suppnotes  = $row['supplier_notes'];
			$exist   = true;
		} else {
			$exist = false;
		}
		mysql_free_result(SupplierDb::$lastresult);
		return $exist;
	}
}
/*
Class OrderDb {
	private static $lastresult;
	
	static public function existOrder($custid, &$onum, &$dateo){
		Database::connect();
		$sql = "SELECT * FROM `order` WHERE `custno`='".$custid."'";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		$next = false;
		$row = mysql_fetch_assoc(OrderDb::$lastresult);
		if ($row){
			$onum  = $row['orderno'];
			$dateo = $row['orderdate'];
			$next   = true;
		} else {
			mysql_free_result(OrderDb::$lastresult);
			$next = false;
		}
		return $next;
	}
	
	static public function createOrder($custid, &$onum, &$dateo){
		Database::connect();
		$dateo =  date("Y-m-d");
		$sql   = "INSERT INTO `order` (`custno`,`orderno`,`orderdate`) VALUES ('".$custid."',NULL,'".$dateo."')";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		
		$sql = "SELECT MAX(`orderno`) FROM `order` WHERE `custno`='".$custid."'";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		
		if (!OrderDb::$lastresult) {
			echo $sql;
			echo "Customer DB Mgmt - createOrder\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
		$row = mysql_fetch_assoc(OrderDb::$lastresult);
		//var_dump($row);
		$onum = $row['MAX(`orderno`)'];
	}

	static public function initListOrderLines($ordnum) {
		Database::connect();
		$sql = "SELECT * FROM orderline WHERE olordno = ".$ordnum;
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::initListOrderLines\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}

	static public function getNextOrderLine(&$codep, &$qty) {
		$next = false;
		$row = mysql_fetch_assoc(OrderDb::$lastresult);
		if ($row){
			$codep  = $row['olcodep'];
			$qty    = $row['olqty'];
			$next   = true;
		} else {
			mysql_free_result(OrderDb::$lastresult);
			$next = false;
		}
		return $next;
	}
	
	static public function existOrderLine($cp,$ordnum){
		Database::connect();
		$sql = "SELECT * FROM orderline WHERE ((olordno = ".$ordnum.") AND (olcodep = ".$cp."))";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::existOrderLine\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
		$exist = false;
		$row = mysql_fetch_assoc(OrderDb::$lastresult);
		if ($row){
			$exist   = true;
		} else {
			mysql_free_result(OrderDb::$lastresult);
			$exist = false;
		}
		return $exist;
	}

	static public function updateOrderLine($cp,$qt,$ordnum){
		Database::connect();
		$sql = "UPDATE orderline SET olqty = ".$qt." WHERE ((olordno = ".$ordnum.") AND (olcodep = ".$cp."))";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::existOrderLine\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}

	static public function deleteOrderLine($cp,$ordnum){
		Database::connect();
		$sql = "DELETE FROM orderline WHERE ((olordno = ".$ordnum.") AND (olcodep = ".$cp."))";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::deleteOrderLine\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}

	static public function addOrderLine($cp,$qt, $ordnum){
		Database::connect();
		$sql   = "INSERT INTO `orderline` (`olcodep`,`olordno`,`olqty`) VALUES ('".$cp."','".$ordnum."','".$qt."')";
		//echo $sql; echo "<br>";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::addOrderLine\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}
	
	//When we click on valider 
	static public function updateOrder($ordnum){
	Database::connect();
	$sql = "UPDATE `order` set valide = 1 where orderno = " .$ordnum. ")" ;
	OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!OrderDb::$lastresult) {
		    echo "OrderDb::existOrderLine\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}
	
	static public function getMaxOrderNum(&$custid){
			$sql = "SELECT MAX(`orderno`) FROM `order` WHERE `custno`='".$custid."'";
		OrderDb::$lastresult = mysql_query($sql, Database::getLink());
		
		if (!OrderDb::$lastresult) {
			echo $sql;
			echo "Customer DB Mgmt - createOrder\n";
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
		$row = mysql_fetch_assoc(OrderDb::$lastresult);
		//var_dump($row);
		$onum = $row['MAX(`orderno`)'];
	}

} 
*/
?>