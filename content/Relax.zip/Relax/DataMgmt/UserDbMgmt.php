<?php
include_once 'DataMgmt\DatabaseMgmt.php';

Class UserDb {

	private static $lastresult;

	static public function checkUserID($userid, &$firstname, &$lastname, &$userprofile) {
		Database::connect();
		$sql    = "SELECT firstname, lastname, userprofile FROM user WHERE userid = '".$userid."'";
		$result = mysql_query($sql, Database::getLink());
		
		if (!$result) {
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}

		$row = mysql_fetch_assoc($result);
		if ($row){
			$firstname   = $row['firstname'];
			$lastname    = $row['lastname'];
			$userprofile = $row['userprofile'];
		 	$trouve = true; 
		} else {
			$trouve = false;
		}
		mysql_free_result($result);
		unset ($sql);
		return $trouve;
	}

	static public function checkUserPWD($userid,$password) {
		Database::connect();
		$sql = "SELECT * FROM user WHERE ((password = '".$password."') AND (userid = '".$userid."'))";
		$result = mysql_query($sql, Database::getLink());
		if (!$result) {
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}

		$row = mysql_fetch_assoc($result);
		if ($row) $pwdok = true; else $pwdok = false;
		mysql_free_result($result);
		unset($sql);
		return $pwdok;	
	}
	
	static public function initListFunctionsFromUserProfile($up) {
		Database::connect();
		$sql = "SELECT * FROM function WHERE fctprofile = ".$up;
		UserDb::$lastresult = mysql_query($sql, Database::getLink());
		if (!UserDb::$lastresult) {
		    echo "Erreur DB, impossible d'effectuer une requête\n";
		    echo 'Erreur MySQL : ' . mysql_error();
		    exit;
		}
	}
	
	static public function getNextFunctionFromUserProfile(&$fid, &$name, &$desc) {
		$next = false;
		$row = mysql_fetch_assoc(UserDb::$lastresult);
		if ($row){
			$fid  = $row['functionid'];
			$name = $row['name'];
			$desc = $row['description'];
			$next = true;
		} else {
			mysql_free_result(UserDb::$lastresult);
			$next = false;
		}
		return $next;
	}
	
}

?>