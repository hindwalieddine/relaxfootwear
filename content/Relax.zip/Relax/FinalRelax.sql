-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 15, 2012 at 06:17 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `relaxfinal`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `admin_id` int(25) NOT NULL auto_increment,
  `admin_name` varchar(25) NOT NULL,
  `admin_pass` varchar(25) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_pass`) VALUES 
(2, 'admin', 'pass'),
(4, 'ad', 'ad');

-- --------------------------------------------------------

-- 
-- Table structure for table `article`
-- 

CREATE TABLE `article` (
  `article_id` int(7) NOT NULL,
  `article_pur_price` float NOT NULL,
  `article_sale_price` int(11) NOT NULL,
  `article_after_solde_price` int(11) NOT NULL,
  `article_supplier_id` int(11) NOT NULL,
  `article_image` text NOT NULL,
  PRIMARY KEY  (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `article`
-- 

INSERT INTO `article` (`article_id`, `article_pur_price`, `article_sale_price`, `article_after_solde_price`, `article_supplier_id`, `article_image`) VALUES 
(3155456, 50000, 90000, 85000, 1, ''),
(5106320, 15000, 50000, 0, 1, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `emp`
-- 

CREATE TABLE `emp` (
  `emp_id` int(20) NOT NULL auto_increment,
  `emp_name` varchar(200) NOT NULL,
  `emp_pass` varchar(200) NOT NULL,
  PRIMARY KEY  (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `emp`
-- 

INSERT INTO `emp` (`emp_id`, `emp_name`, `emp_pass`) VALUES 
(1, 'user', 'pass');

-- --------------------------------------------------------

-- 
-- Table structure for table `inserted_article`
-- 

CREATE TABLE `inserted_article` (
  `inserted_id` int(11) NOT NULL auto_increment,
  `inserted_article` int(7) NOT NULL,
  `inserted_date` date NOT NULL,
  `qty1` int(11) NOT NULL,
  `qty2` int(11) NOT NULL,
  `qty3` int(11) NOT NULL,
  `qty4` int(11) NOT NULL,
  `qty5` int(11) NOT NULL,
  `qty6` int(11) NOT NULL,
  `qty7` int(11) NOT NULL,
  `qty8` int(11) NOT NULL,
  `qty9` int(11) NOT NULL,
  `qty10` int(11) NOT NULL,
  `qty11` int(11) NOT NULL,
  `qty12` int(11) NOT NULL,
  `qty13` int(11) NOT NULL,
  PRIMARY KEY  (`inserted_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

-- 
-- Dumping data for table `inserted_article`
-- 

INSERT INTO `inserted_article` (`inserted_id`, `inserted_article`, `inserted_date`, `qty1`, `qty2`, `qty3`, `qty4`, `qty5`, `qty6`, `qty7`, `qty8`, `qty9`, `qty10`, `qty11`, `qty12`, `qty13`) VALUES 
(24, 3155456, '2012-02-11', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13),
(48, 5106320, '2012-02-11', 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0),
(52, 5106320, '2012-02-12', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(63, 5106320, '2012-02-13', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `supplier`
-- 

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL auto_increment,
  `supplier_name` varchar(500) NOT NULL,
  `supplier_phone` varchar(60) NOT NULL,
  `supplier_mobile` varchar(60) NOT NULL,
  `supplier_address` text NOT NULL,
  `supplier_notes` text NOT NULL,
  PRIMARY KEY  (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `supplier`
-- 

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `supplier_phone`, `supplier_mobile`, `supplier_address`, `supplier_notes`) VALUES 
(1, 'supp1', '', '', '', ''),
(2, 'supp2', '', '', '', ''),
(3, 'supp3', '', '', '', '');
