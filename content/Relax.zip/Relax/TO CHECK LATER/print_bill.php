<html>
<head>
<script type='text/javascript'>
function updateWindow() {parent.window.frames['iframe'].location = 'home.php';}

</script> 
</head>
<body >
<br><br><br>
<table align="center" cellpadding="0" cellspacing="0" >
<tr>
<td width="150" height="155" align="center">
<A HREF="javascript:parent.window.frames['iframe'].print()"><img src="images/print.png" style="border:0" /><br>Print</A></td></tr>
<tr><td height="155" align="center">
<a href="home.php" target="_top"><img src="images/home_64.png" style="border:0"><br>New Fatcure/home</a>
</td></tr>

<tr><td height="155" align="center">
<a href="../Logout.php" target="_top"><img src="images/exit.png" style="border:0"><br>Logout</a>
</td></tr>

</table>
</body>
</html>