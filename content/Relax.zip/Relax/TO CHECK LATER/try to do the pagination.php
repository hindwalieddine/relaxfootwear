<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$date=date('Y-m-d');
$from=$_POST['fromdatetxt'];
$to=$_POST['todate'];
//echo $from; echo "<br>"; echo $to;
?>
<html>
<form name="GetInsertform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table width="741" height="307" align="center" >
    <tr>
      <td width="187" valign="top">
      <table width="183" border="0" align="left">
      <tr>
        <td width="79">From date</td>
      <td width="88"><input type="text" size="10" name="fromdatetxt" value="<?php echo $date ?>"/></td></tr>
      <tr><td>To date</td>
      <td><input type="text" size="10" name="todate" value="<?php echo $date?>"/></td></tr>
      <tr><td align="center" colspan="2"><input type="submit" name="submit" value="Search" /></td></tr>
      
      
      
      
      
      </table></td>
      
      <td width="542">
      
      
      <table width="446" border="1" cellpadding="0" cellspacing="0" align="center">
  <tr bgcolor="#66CCCC" align="center">
    <td width="76">Serie 1</td>
    <td width="30">18</td>
    <td width="30">19</td>
    <td width="30">20</td>
    <td width="30">21</td>
    <td width="30">22</td>
    <td width="30">23</td>
    <td width="30">24</td>
    <td width="30">25</td>
    <td width="30">26</td>
    <td width="30"></td>
  </tr>
  <tr bgcolor="#66CCCC" align="center">
    <td width="76">Serie 2</td>
    <td width="30">27</td>
    <td width="30">28</td>
    <td width="30">29</td>
    <td width="30">30</td>
    <td width="30">31</td>
    <td width="30">32</td>
    <td width="30">33</td>
    <td width="30">34</td>
    <td width="30">35</td>
    <td width="30">36</td>
  </tr>
  <tr bgcolor="#66CCCC" align="center">
    <td>Serie 3/4/5</td>
    <td width="30">35</td>
    <td width="30">36</td>
    <td width="30">37</td>
    <td width="30">38</td>
    <td width="30">39</td>
    <td width="30">40</td>
    <td width="30">41</td>
    <td width="30">42</td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php
	  //Pour les pagination du page
	  $messagesParPage=20; //Nous allons afficher 5 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM serie1,serie2,serie3,serie4,serie5,serie6_accessoires, serie8_bags, serie9_bas  WHERE `serie1_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie2_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie3_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie4_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie5_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie6_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie8_date` BETWEEN  \"$from\" AND  \"$to\"
  AND `serie9_date` BETWEEN  \"$from\" AND  \"$to\"	
										"); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire

$query1=mysql_query("SELECT * FROM  `serie1` WHERE  `serie1_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie1_article` LIMIT ".$premiereEntree.", ".$messagesParPage." ");
    
while($result1=mysql_fetch_array($query1)){

	?>
  <tr align="center">
    <td><?php echo $result1['serie1_article'];?></td>
    <td width="30"><?php echo $result1['serie1_18'];?></td>
    <td width="30"><?php echo $result1['serie1_19'];?></td>
    <td width="30"><?php echo $result1['serie1_20'];?></td>
    <td width="30"><?php echo $result1['serie1_21'];?></td>
    <td width="30"><?php echo $result1['serie1_22'];?></td>
    <td width="30"><?php echo $result1['serie1_23'];?></td>
    <td width="30"><?php echo $result1['serie1_24'];?></td>
    <td width="30"><?php echo $result1['serie1_25'];?></td>
    <td width="30"><?php echo $result1['serie1_26'];?></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie2 
$query2=mysql_query("SELECT * FROM  `serie2` WHERE  `serie2_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie2_article` LIMIT 0 , 30 "); 
    
while($result2=mysql_fetch_array($query2)){

	?>
  <tr align="center">
    <td><?php echo $result2['serie2_article'];?></td>
    <td width="30"><?php echo $result2['serie2_27'];?></td>
    <td width="30"><?php echo $result2['serie2_28'];?></td>
    <td width="30"><?php echo $result2['serie2_29'];?></td>
    <td width="30"><?php echo $result2['serie2_30'];?></td>
    <td width="30"><?php echo $result2['serie2_31'];?></td>
    <td width="30"><?php echo $result2['serie2_32'];?></td>
    <td width="30"><?php echo $result2['serie2_33'];?></td>
    <td width="30"><?php echo $result2['serie2_34'];?></td>
    <td width="30"><?php echo $result2['serie2_35'];?></td>
    <td width="30"><?php echo $result2['serie2_36'];?></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie3
$query3=mysql_query("SELECT * FROM  `serie3` WHERE  `serie3_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie3_article` LIMIT 0 , 30 "); 
    
while($result3=mysql_fetch_array($query3)){

	?>
  <tr align="center">
    <td><?php echo $result3['serie3_article'];?></td>
    <td width="30"><?php echo $result3['serie3_35'];?></td>
    <td width="30"><?php echo $result3['serie3_36'];?></td>
    <td width="30"><?php echo $result3['serie3_37'];?></td>
    <td width="30"><?php echo $result3['serie3_38'];?></td>
    <td width="30"><?php echo $result3['serie3_39'];?></td>
    <td width="30"><?php echo $result3['serie3_40'];?></td>
    <td width="30"><?php echo $result3['serie3_41'];?></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie4
$query4=mysql_query("SELECT * FROM  `serie4` WHERE  `serie4_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie4_article` LIMIT 0 , 30 "); 
    
while($result4=mysql_fetch_array($query4)){

	?>
  <tr align="center">
    <td><?php echo $result4['serie4_article'];?></td>
    <td width="30"><?php echo $result4['serie4_35'];?></td>
    <td width="30"><?php echo $result4['serie4_36'];?></td>
    <td width="30"><?php echo $result4['serie4_37'];?></td>
    <td width="30"><?php echo $result4['serie4_38'];?></td>
    <td width="30"><?php echo $result4['serie4_39'];?></td>
    <td width="30"><?php echo $result4['serie4_40'];?></td>
    <td width="30"><?php echo $result4['serie4_41'];?></td>
    <td width="30"><?php echo $result4['serie4_42'];?></td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie5
$query5=mysql_query("SELECT * FROM  `serie5` WHERE  `serie5_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie5_article` LIMIT 0 , 30 "); 
    
while($result5=mysql_fetch_array($query5)){

	?>
  <tr align="center">
    <td><?php echo $result5['serie5_article'];?></td>
    <td width="30"><?php echo $result5['serie5_35'];?></td>
    <td width="30"><?php echo $result5['serie5_36'];?></td>
    <td width="30"><?php echo $result5['serie5_37'];?></td>
    <td width="30"><?php echo $result5['serie5_38'];?></td>
    <td width="30"><?php echo $result5['serie5_39'];?></td>
    <td width="30"><?php echo $result5['serie5_40'];?></td>
    <td width="30"><?php echo $result5['serie5_41'];?></td>
    <td width="30"><?php echo $result5['serie5_42'];?></td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie6
$query6=mysql_query("SELECT * FROM  `serie6_accessoires` WHERE  `serie6_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie6_article` LIMIT 0 , 30 "); 
    
while($result6=mysql_fetch_array($query6)){

	?>
  <tr align="center">
    <td><?php echo $result6['serie6_article'];?></td>
    <td width="30"><?php echo $result6['serie6_qty'];?></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie8
$query8=mysql_query("SELECT * FROM  `serie8_bags` WHERE  `serie8_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie8_article` LIMIT 0 , 30 "); 
    
while($result8=mysql_fetch_array($query8)){

	?>
  <tr align="center">
    <td><?php echo $result8['serie8_article'];?></td>
    <td width="30"><?php echo $result8['serie8_qty'];?></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
  </tr>
  <?php } ?>
  <?php
//get all the serie8
$query9=mysql_query("SELECT * FROM  `serie9_bas` WHERE  `serie9_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `serie9_article` LIMIT 0 , 30 "); 
    
while($result9=mysql_fetch_array($query9)){

	?>
  <tr align="center">
    <td><?php echo $result9['serie9_article'];?></td>
    <td width="30"><?php echo $result9['serie9_qty'];?></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td width="30"></td>
    <td></td>
  </tr>
  <?php } ?>
</table>
      
 <?php
 
 //pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="Get_All_inserted_articles.php?page='.$i.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
 
 ?>
      
      </td>
    </tr>
    <tr>
      <td></td>
    <tr>
      <td>
      
    </tr>
    <?php
	if(($from==NULL)&&($to==NULL)){ 	?>
    <script language="javascript">
	alert("Please choose 2 dates");
	//location = 'insert_supplier.php';
	</script>
    <?php
	exit;
	}
	?>
  </table>
</form>

</html>