<?php session_start(); 
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
if(isset($_POST['submit'])){
	
$articleid=$_POST['articletxt'];
$arcticle_purch_price=$_POST['purchasetxt'];
$article_sale_price=$_POST['salepricetxt'];
$after_solde_price=$_POST['aftersalepricetxt'];
$supp_name=$_POST['article_supp_name'];
//echo $articleid;

//query2="INSERT INTO  `article` (  `article_id` ,  `article_pur_price` ,  `article_sale_price` ,  `article_after_solde_price` ,  `article_supplier` ) VALUES ($articleid,  $arcticle_purch_price ,  $article_sale_price ,  $aftersalepricetxt ,  $article_supp_name);";
}
?>
<html>
Insert new Article:<br />
<form name="menu1" action="<?php echo $_SERVER[PHP_SELF] ?>" method="post">
  <table>
    <tr>
      <td>Article number: </td>
      <td><input type="text" name="articletxt" /></td>
    </tr>
    <tr>
      <td>Purchase price:</td>
      <td><input type="text" name="purchasetxt" /></td>
    </tr>
    <tr>
      <td>Sale price:</td>
      <td><input type="text" name="salepricetxt" /></td>
    </tr>
    <tr>
      <td>After solde price:</td>
      <td><input type="text" name="aftersalepricetxt" /></td>
    </tr>
     <?php
	$result=mysql_query("SELECT * FROM `supplier` ORDER BY supplier_name");
	//echo $query; echo "<br>";
    ?>
	    <tr>
      <td>Supplier:</td>
      <td><select name="article_supp_name">
	  <?php
	while($getSupplier=mysql_fetch_array($result)){
	echo $getSupplier['supplier_name'];
		?>

         
          <option value="<?php echo $getSupplier['supplier_name'];?>"> <?php echo $getSupplier['supplier_name'];?> </option>
        
        <?php
    }
	?>
    </select>
      <td>
    </tr>
    <tr><td><input type="submit" value="Save"> </td></tr>
  </table>
</form>
</html>