<?php
require_once("connection.php");
	$query="SELECT * 
FROM  `supplier` 
ORDER BY supplier_name
LIMIT 0 , 30";
	//ORDER BY supplier_name";
	echo $query; echo "<br>";
	
	//$query=mysql_query("SELECT * 
//FROM  `supplier` 
//ORDER BY supplier_name
//LIMIT 0 , 30");
	@mysql_query($query);
	while($result=mysql_fetch_array($query)){
		echo "11111111111111111";
		echo "result: ".$result;
	echo $result['supplier_name']; 
	}

/*
$CheckLog=mysql_query("SELECT * FROM `admin` ");
@mysql_query($CheckLog);
static $chek=0;
while ($row = mysql_fetch_array($CheckLog)) {
*/

?>