<?php
function check_login_admin()
{
	session_start();
if($_SESSION['check_login_admin'] != 'already_login_admin')
{
$LoginLink = "<a href=\"../index.php\">Login</a>";
echo "your time is out click here to $LoginLink";
exit();
}
else{};
}//function







function login_admin(){
	session_start();
require_once("config/connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	
foreach($_POST as $key => $value)
	{
	     $_POST[$key] = mysql_real_escape_string($value);
	}
	
	
	$user = $_POST[usertxt];
	$pass = $_POST[passtxt];
	$login_succes=0;
	
$select_admins=mysql_query("SELECT * FROM `admin`");
@mysql_query($select_admins);
while($row1 = mysql_fetch_array($select_admins)){
$login_succes	=	2;
$user_right 	=	$row1['admin_name'];
$pass_right	    =	$row1['admin_pass'];
$admin_id    	=	$row1['admin_id'];

	if ($user == $user_right && $pass == $pass_right)
	{ 
		$login_succes=1;
		$_SESSION['check_login_admin']   =  "already_login_admin" ;
		
		?> <script type="text/javascript"> window.location="admin/home.php"; </script> <?php
		
	}
	
  }
 if($login_succes == 2)
  { 
    $_SESSION['invalid_pass1']="invalid_pass1";
	 ?> <script type="text/javascript"> window.location="index.php"; </script> <?php
	 }
    
   }
   
}//function


?>