<?php 
require_once("include/function.php");
login_admin();
?>
