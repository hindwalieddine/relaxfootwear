<html>
<table align="center" bgcolor="#3399FF">
<tr><td width="90"><a href="index.php">Home</a></td>
<td width="90"><a href="articles.php">Articles</a></td>
<td width="90"><a href="suppliers.php">Suppliers</a></td>
<td width="90"><a href="customers.php">Customers</a></td>
<td width="90"><a href="bills.php">Bills</a></td>
<td width="90"><a href="loout.php">Logout</a></td>

</tr>
</table>
</html>