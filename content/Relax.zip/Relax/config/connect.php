﻿<?php

$link = mysql_connect('localhost', 'root', '');  //Relax pc
//$link = mysql_connect('localhost', 'root', 'admin'); // laptop 
//$link = mysql_connect('localhost', 'admin', 'admin'); // work pc
if (!$link) {
   die('Impossible de se connecter : ' . mysql_error());
}

// Rendre la base de données foo, la base courante
$db_selected = mysql_select_db('realaxfinal', $link);
if (!$db_selected) {
   die ('Impossible de sélectionner la base de données : ' . mysql_error());
}
?> 

