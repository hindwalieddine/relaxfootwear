<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$date=date('Y-m-d');
$from=$_POST['fromdatetxt'];
$to=$_POST['todate'];
$sum=0;
		  $tot=0;
		  $nb=$_GET[nb]; //echo "nb: ".$nb;

//echo $from; echo "<br>"; echo $to;
?>
<html>  
<?php
// Get the total of quantity in stock
$queryTotShoes=mysql_query("SELECT (SUM(qty1)+SUM(qty2)+SUM(qty3)+SUM(qty4)+SUM(qty5)+SUM(qty6)+SUM(qty7)+SUM(qty8)+SUM(qty9)+SUM(qty10)+SUM(qty11)+SUM(qty12)+SUM(qty13)) as totshoes FROM inserted_article 
WHERE inserted_article>0 AND inserted_article<6000000
OR inserted_article>6999999 AND inserted_article<8000000 ");
while($restot=mysql_fetch_array($queryTotShoes)){
	$totshoes=$restot[totshoes];}
// Get the total price in stock
$text="SELECT * FROM article ORDER BY article_id";
$query=mysql_query($text);

		  while($result=mysql_fetch_array($query)){
			     $article=$result['article_id']; //echo "article :".$article;
				 $price=$result['article_sale_price'];
				 $saleprice=$result['article_sale_price'];
 $query2=mysql_query("SELECT * FROM `inserted_article` WHERE `inserted_article`='$article'");

	      $i=0;
		  $qty1=0;
		  $qty2=0;
		  $qty3=0;
		  $qty4=0;
		  $qty5=0;
		  $qty6=0;
		  $qty7=0;
		  $qty8=0;
		  $qty9=0;
		  $qty10=0;
		  $qty11=0;
		  $qty12=0;
		  $qty13=0;

while($result2=mysql_fetch_array($query2)){
	$qty1a=$result2['qty1']; 
	$qty2a=$result2['qty2'];  
	$qty3a=$result2['qty3'];  
	$qty4a=$result2['qty4'];  
 	$qty5a=$result2['qty5'];  
	$qty6a=$result2['qty6']; 
	$qty7a=$result2['qty7'];  
	$qty8a=$result2['qty8'];  
	$qty9a=$result2['qty9']; 
	$qty10a=$result2['qty10'];  
	$qty11a=$result2['qty11'];  
	$qty12a=$result2['qty12']; 
	$qty13a=$result2['qty13']; 
	$qty1=$qty1+$qty1a;   
	$qty2=$qty2+$qty2a;  
	$qty3=$qty3+$qty3a;  
	$qty4=$qty4+$qty4a;     
	$qty5=$qty5+$qty5a;
	$qty6=$qty6+$qty6a;
	$qty7=$qty7+$qty7a;  // echo  "qty7 ".$qty7;  
	$qty8=$qty8+$qty8a;
	$qty9=$qty9+$qty9a;
	$qty10=$qty10+$qty10a;     
	$qty11=$qty11+$qty11a;
	$qty12=$qty12+$qty12a;
	$qty13=$qty13+$qty13a;   //$i++; echo "<br>";  
          }//End while $result2
  $sum=($qty1+$qty2+$qty3+$qty4+$qty5+$qty6+$qty7+$qty8+$qty9+$qty10+$qty11+$qty12+$qty13);
  $mul=($sum*$price); //echo $mul;echo "<br>";
  $mulprices=$mul+$mulprices; //echo "mul1: ".$mulprices; echo "<br>";
		  }

	
?>
<table align="center">
<tr>
<td valign="top">
<table width="200">
<tr> <td width="84">Total:</td> <td width="174"><?php echo $totshoes;?></td>
</tr>
<tr><td>Price</td>
<td> <?php echo" ";echo $mulprices;?></td></tr>
</table>
</td>
<td>
<form name="RelaxInventaireForm" action="<?php $_SERVER['PHP_SELF']?>" method="post">

<table width="610" border="1" bordercolor="#6699CC" cellpadding="0" cellspacing="0" align="center">
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35"> 1</td>
            <td width="35">18</td>
            <td width="35">19</td>
            <td width="35">20</td>
            <td width="35">21</td>
            <td width="35">22</td>
            <td width="35">23</td>
            <td width="35">24</td>
            <td width="35">25</td>
            <td width="35">26</td>
            <td width="35">27</td>
            <td width="35">28</td>
            <td width="35">29</td>
            <td width="35">30</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35"> 2</td>
            <td width="35">25</td>
            <td width="35">26</td>
            <td width="35">27</td>
            <td width="35">28</td>
            <td width="35">29</td>
            <td width="35">30</td>
            <td width="35">31</td>
            <td width="35">32</td>
            <td width="35">33</td>
            <td width="35">34</td>
            <td width="35">35</td>
            <td width="35">36</td>
            <td width="35">37</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35">3/4/5</td>
            <td width="35">35</td>
            <td width="35">36</td>
            <td width="35">37</td>
            <td width="35">38</td>
            <td width="35">39</td>
            <td width="35">40</td>
            <td width="35">41</td>
            <td width="35">42</td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="15"></td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70">Article</td>
            <td width="70">Price</td>
            <td width="35"> 7</td>
            <td width="35">39</td>
            <td width="35">40</td>
            <td width="35">41</td>
            <td width="35">41.5</td>
            <td width="35">42</td>
            <td width="35">42.5</td>
            <td width="35">43</td>
            <td width="35">43.5</td>
            <td width="35">44</td>
            <td width="35">45</td>
            <td width="35">46</td>
            <td width="35">47</td>
            <td width="35">48</td>
          </tr>
          <?php
		  
		   
	  //Pour les pagination du page
	  $messagesParPage=45; //Nous allons afficher 3 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM article "); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire

// La requête sql pour récupérer les messages de la page actuelle.
$text="SELECT * FROM article ORDER BY article_id";
$query=mysql_query($text." LIMIT ".$premiereEntree.", ".$messagesParPage." ");

		  while($result=mysql_fetch_array($query)){
			     $article=$result['article_id']; //echo "article :".$article;
				 $saleprice=$result['article_sale_price'];
 $query2=mysql_query("SELECT * FROM `inserted_article` WHERE `inserted_article`='$article'");

	      $i=0;
		  $qty1=0;
		  $qty2=0;
		  $qty3=0;
		  $qty4=0;
		  $qty5=0;
		  $qty6=0;
		  $qty7=0;
		  $qty8=0;
		  $qty9=0;
		  $qty10=0;
		  $qty11=0;
		  $qty12=0;
		  $qty13=0;
while($result2=mysql_fetch_array($query2)){
	$qty1a=$result2['qty1']; //echo "qty1a".$qty1a; echo "       ";
	$qty2a=$result2['qty2'];  //echo "qty2a".$qty2a; echo "       ";
	$qty3a=$result2['qty3'];  //echo "qty3a".$qty3a; echo "       ";
	$qty4a=$result2['qty4'];  
 	$qty5a=$result2['qty5'];  
	$qty6a=$result2['qty6']; 
	$qty7a=$result2['qty7'];  //echo  "qty7a ".$qty7a;  echo "       ";
	$qty8a=$result2['qty8'];  
	$qty9a=$result2['qty9']; 
	$qty10a=$result2['qty10'];  
	$qty11a=$result2['qty11'];  
	$qty12a=$result2['qty12']; 
	$qty13a=$result2['qty13']; 
	$qty1=$qty1+$qty1a;   // echo  "qty1 ".$qty1;
	$qty2=$qty2+$qty2a;   // echo  "qty2 ".$qty2;
	$qty3=$qty3+$qty3a;   // echo  "qty3 ".$qty3;
	$qty4=$qty4+$qty4a;     
	$qty5=$qty5+$qty5a;
	$qty6=$qty6+$qty6a;
	$qty7=$qty7+$qty7a;  // echo  "qty7 ".$qty7;  
	$qty8=$qty8+$qty8a;
	$qty9=$qty9+$qty9a;
	$qty10=$qty10+$qty10a;     
	$qty11=$qty11+$qty11a;
	$qty12=$qty12+$qty12a;
	$qty13=$qty13+$qty13a;   //$i++; echo "<br>";  
          }//End while $result2
  $sum=($qty1+$qty2+$qty3+$qty4+$qty5+$qty6+$qty7+$qty8+$qty9+$qty10+$qty11+$qty12+$qty13);
  $tot=($tot+$sum);
  // echo $tot;echo "<br>";  
		  
		  											?>
		   <tr align="center">
           <td><?php echo $article;?></td>
            <td><?php echo $saleprice;?></td>
            <td><font color="#FF0000"><?php echo $sum;?></td>
            <td width="35"><?php echo $qty1;?></td>
            <td width="35"><?php echo $qty2;?></td>
            <td width="35"><?php echo $qty3;?></td>
            <td width="35"><?php echo $qty4;?></td>
            <td width="35"><?php echo $qty5;?></td>
            <td width="35"><?php echo $qty6;?></td>
            <td width="35"><?php echo $qty7;?></td>
            <td width="35"><?php echo $qty8;?></td>
            <td width="35"><?php echo $qty9;?></td>
            <td width="35"><?php echo $qty10;?></td>
            <td width="35"><?php echo $qty11;?></td>
            <td width="35"><?php echo $qty12;?></td>
            <td width="35"><?php echo $qty13;?></td>
            
        </tr>
        <?php                                        
											}//End while $result1
	   
	?>
   

      		   <tr align="center">
           <td></td>
            <td></td>
            <td></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            
        </tr>
        </table>
<?php
//pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="RelaxInventaire.php?page='.$i.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
?>

</form>
</td>
</tr>
</table>
</html>