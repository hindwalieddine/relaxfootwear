<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$date=date('Y-m-d');
$from=$_POST['fromdatetxt'];
$to=$_POST['todate'];
$F=$_GET['f'];
$t=$_GET['t'];
$sum=0;

//echo $from; echo "<br>"; echo $to;
?>
<html>  
<form name="GetVenteform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table width="741" height="307" align="center" >
    <tr>
      <td width="187" valign="top"><table width="185" border="0" align="left">
          <tr>
            <td width="79">From date</td>
            <td width="88"><input type="text" size="10" name="fromdatetxt" value="<?php echo $date ?>"/></td>
          </tr>
          <tr>
            <td>To date</td>
            <td><input type="text" size="10" name="todate" value="<?php echo $date?>"/></td>
          </tr>
          <tr>
            <td align="center" colspan="2"><input type="submit" name="submit" value="Search" /></td>
          </tr>
        </table></td>
      <td width="542"><table width="610" border="1" cellpadding="0" cellspacing="0" align="center">
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35"> 1</td>
            <td width="35">18</td>
            <td width="35">19</td>
            <td width="35">20</td>
            <td width="35">21</td>
            <td width="35">22</td>
            <td width="35">23</td>
            <td width="35">24</td>
            <td width="35">25</td>
            <td width="35">26</td>
            <td width="35">27</td>
            <td width="35">28</td>
            <td width="35">29</td>
            <td width="35">30</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35"> 2</td>
            <td width="35">25</td>
            <td width="35">26</td>
            <td width="35">27</td>
            <td width="35">28</td>
            <td width="35">29</td>
            <td width="35">30</td>
            <td width="35">31</td>
            <td width="35">32</td>
            <td width="35">33</td>
            <td width="35">34</td>
            <td width="35">35</td>
            <td width="35">36</td>
            <td width="35">37</td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70"></td>
            <td width="70"></td>
            <td width="35">3/4/5</td>
            <td width="35">35</td>
            <td width="35">36</td>
            <td width="35">37</td>
            <td width="35">38</td>
            <td width="35">39</td>
            <td width="35">40</td>
            <td width="35">41</td>
            <td width="35">42</td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="35"></td>
            <td width="15"></td>
          </tr>
          <tr bgcolor="#66CCCC" align="center">
            <td width="70">Article</td>
            <td width="70">Price</td>
            <td width="35"> 7</td>
            <td width="35">39</td>
            <td width="35">40</td>
            <td width="35">41</td>
            <td width="35">41.5</td>
            <td width="35">42</td>
            <td width="35">42.5</td>
            <td width="35">43</td>
            <td width="35">43.5</td>
            <td width="35">44</td>
            <td width="35">45</td>
            <td width="35">46</td>
            <td width="35">47</td>
            <td width="35">48</td>
            <td width="15"></td>
          </tr>
          <?php
 /*
	  //Pour les pagination du page
	  $messagesParPage=23; //Nous allons afficher 24 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM article "); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire

// La requête sql pour récupérer les messages de la page actuelle.
*/
/* if($i==0){ 
$query1="SELECT * FROM  `inserted_article` WHERE  `inserted_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `inserted_article` LIMIT ";
echo "query1 ". $query1;*/
$query1=mysql_query("SELECT * FROM  `vente_article` WHERE  `vente_date` BETWEEN  \"$from\" AND  \"$to\" ORDER BY  `fact_id` ");
/*}*/

/*
if(($f!=NULL) && ($t!=NULL) && ($i>0)){
	$query2="SELECT * FROM  `inserted_article` WHERE  `inserted_date` BETWEEN  \"$f\" AND  \"$t\" ORDER BY  `inserted_article` LIMIT ".$premiereEntree.", ".$messagesParPage." ";
	echo "query2 ". $query2;
$query1=mysql_query("SELECT * FROM  `inserted_article` WHERE  `inserted_date` BETWEEN  \"$f\" AND  \"$t\" ORDER BY  `inserted_article` LIMIT ".$premiereEntree.", ".$messagesParPage." ");}

 */  
	
		$total=0;
while($result1=mysql_fetch_array($query1)){
$article=$result1['vente_article'];
$qty1=$result1['qty1'];
$qty2=$result1['qty2'];
$qty3=$result1['qty3'];
$qty4=$result1['qty4'];
$qty5=$result1['qty5'];
$qty6=$result1['qty6'];
$qty7=$result1['qty7'];
$qty8=$result1['qty8'];
$qty9=$result1['qty9'];
$qty10=$result1['qty10'];
$qty11=$result1['qty11'];
$qty12=$result1['qty12'];
$qty13=$result1['qty13'];
$id=$result1['vente_id'];
$cash=$result1['cash'];

$sum=($qty1+$qty2+$qty3+$qty4+$qty5+$qty6+$qty7+$qty8+$qty9+$qty10+$qty11+$qty12+$qty13);
$total=($total+$sum);
	?>
          <tr align="center">
            <td><?php echo $article;?></td>
            <td><?php echo $result2['cash'];?></td>
            <td><?php echo $id;?></td>
            <td width="35"><?php echo $result1['qty1'];?></td>
            <td width="35"><?php echo $result1['qty2'];?></td>
            <td width="35"><?php echo $result1['qty3'];?></td>
            <td width="35"><?php echo $result1['qty4'];?></td>
            <td width="35"><?php echo $result1['qty5'];?></td>
            <td width="35"><?php echo $result1['qty6'];?></td>
            <td width="35"><?php echo $result1['qty7'];?></td>
            <td width="35"><?php echo $result1['qty8'];?></td>
            <td width="35"><?php echo $result1['qty9'];?></td>
            <td width="35"><?php echo $result1['qty10'];?></td>
            <td width="35"><?php echo $result1['qty11'];?></td>
            <td width="35"><?php echo $result1['qty12'];?></td>
            <td width="35"><?php echo $result1['qty13'];?></td>
            <td height=""></td>

          <?php } 
?>
                    <tr align="center">
            <td>Total</td>
            <td></td>
            <td><?php echo $total;?></td>
            <td width="21"></td>
            <td width="17"></td>
            <td width="21"></td>
            <td width="28"></td>
            <td width="21"></td>
            <td width="28"></td>
            <td width="28"></td>
            <td width="31"></td>
            <td width="21"></td>
            <td></td>
          </tr>
      </table>
            <?php
			/*
//pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="Get_All_inserted_articles-mazbouta.php?page='.$i.'?from='.$from.'?to='.$to.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
*/
?>
    </td>
    </tr>
    <tr>
      <td></td>
    <tr>
      <td>
    </tr>
    <tr><td></td>
        <td></td>
        
    <?php
	if(($from==NULL)&&($to==NULL)){ 	?>
    <script language="javascript">
	//alert("Please choose 2 dates");
	//location = 'insert_supplier.php';
	</script>
    <?php
	exit;
	}
	?>
  </table>
  <?php echo $sum; ?>
</form>
</html>