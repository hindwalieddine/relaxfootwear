<?php
ob_start();
include_once("menu.php");
include_once("../config/connect.php");
	$FirstArticle=$_POST['articleID'];
	$SecondArticle=$_POST['articleIDa'];
	$ThirdArticle=$_POST['articleIDb'];
	$ForthArticle=$_POST['articleIDc'];
    $FifthArticle=$_POST['articleIDd'];
	$SixthArticle=$_POST['articleIDe'];
	
	$FirstSize=$_POST['size'];
	$SecondSize=$_POST['sizea'];
	$ThirdSize=$_POST['sizeb'];
	$ForthSize=$_POST['sizec'];
	$FifthSize=$_POST['sized'];
	$SixthSize=$_POST['sizee'];
	
	$FirstQty=$_POST['quantity'];
	$SecondQty=$_POST['quantitya'];
	$ThirdQty=$_POST['quantityb'];
	$ForthQty=$_POST['quantityc'];
	$FifthQty=$_POST['quantityd'];
	$SixthQty=$_POST['quantitye'];
	
	$FirstCash=$_POST['Cash'];
	$SecondCash=$_POST['Casha'];
	$ThirdCash=$_POST['Cashb'];
	$ForthCash=$_POST['Cashc'];
	$FifthCash=$_POST['Cashd'];
	$SixthCash=$_POST['Cashe'];
if(isset($_POST['articleForm-reset'])){
	echo "form sumited";
	if (($FirstArticle!=NULL)&&($FirstSize!=NULL)&&($FirstQty!=NULL)&&($FirstCash!=NULL)){
		if(($FirstArticle<2000000) && ($FirstSize=180)){ echo "180";
			$q="INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` ,  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' ); "; echo $q;
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` ,  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' ); ");	                                 }//end if size=18
	if(($FirstArticle<2000000) && ($FirstSize=190)){ echo "190";
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` ,  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' ); ");	                             }
                                                                                         }//end if size=19
                         }//end if

?>
<HTML>
<HEAD>
<style type="text/css">
body{
background-repeat:no-repeat;
font-family: Trebuchet MS, Lucida Sans Unicode, Arial, sans-serif;
height:100%;
background-color: #FFF;
margin:0px;
padding:0px;
background-image:url('/images/heading3.gif');
background-repeat:no-repeat;
padding-top:85px;
}

fieldset{
width:500px;
margin-left:10px;
}

</style>
<!-- script type="text/javascript" src="jquery-1.5.1.min.js"></script -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<!-- script to calculate automaticly... https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js -->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.autotab.js"></script>
<!-- Begin 1st line  -->
<!--  from 1st article to 1st size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleID, #size').autotab_magic().autotab_filter('numeric');
});
</script>
<!--  from 1st size to the 2nd article  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#size, #articleIDa').autotab_magic().autotab_filter('numeric');
});


<SCRIPT LANGUAGE="JavaScript"><!--
function cent(amount) {
     return (amount == Math.floor(amount)) ? amount + '.00' : (  (amount*10 == Math.floor(amount*10)) ? amount + '0' : amount);
}

function total(what,number) {
    var grandTotal = 0;
    for (var i=0;i<number;i++) {
        if (what.elements['price' + i].value == '')
            what.elements['price' + i].value == '0.00'; // fix for Opera.
        grandTotal += (what.elements['price' + i].value - 0) * (what.elements['quantity' + i].value - 0);
    }
    what.grandTotal.value = cent(Math.round(grandTotal*Math.pow(10,2))/Math.pow(10,2));
}
//--></SCRIPT>

</script>

<!--when we click on the 1st article -->

<!--   to get the multiple for the 1st line   price1 -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getmultipleprice.php?qty=" + $("#quantity").val() +"&p=" + $("#price1").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1a") {
$("#price1").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 1st Line -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getsum.php?qty=" + $("#quantity").val() + "&?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "total") {
$("#total").val(item.value);
}
});
});
});
</script>
<!--End 1st Line -->
<!-- Begin 2nd line  -->

<!--  from 2nd article to 2nd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDa, #sizea').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 2nd size to the 3nd article  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#sizea, #articleIDb').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDa").bind("change", function(e){
$.getJSON("getarticlea.php?aID=" + $("#articleIDa").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricea") {
$("#pricea").val(item.value);
} else if (item.field == "price1a") {
$("#price1a").val(item.value);
} else if (item.field == "diff2") {
$("#diff2").val(item.value);
} else if (item.field == "Casha") {
$("#Casha").val(item.value);
} else if (item.field == "quantitya") {
$("#quantitya").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 2nd line with the price1a -->
<script>
$("#quantitya").bind("change", function(e){
$.getJSON("getmultiplepricea.php?qty=" + $("#quantitya").val() +"&p=" + $("#price1a").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Casha") {
$("#Casha").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 1st Line -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getsuma.php?qty=" + $("#quantitya").val() + "&?aID=" + $("#articleIDa").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Casha") {
$("#Casha").val(item.value);
}
});
});
});
</script>
<!-- End of 2nd Line -->

<!-- Begin 3rd Line -->

<!--  from 3rd article to 3rd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDb, #sizeb').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 3rd size to the 4th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sizeb, #articleIDc').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDb").bind("change", function(e){
$.getJSON("getarticleb.php?aID=" + $("#articleIDb").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "priceb") {
$("#priceb").val(item.value);
} else if (item.field == "price1b") {
$("#price1b").val(item.value);
} else if (item.field == "diff3") {
$("#diff3").val(item.value);
} else if (item.field == "Cashb") {
$("#Cashb").val(item.value);
} else if (item.field == "quantityb") {
$("#quantityb").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 3rd line with the price1b -->
<script>
$("#quantityb").bind("change", function(e){
$.getJSON("getmultiplepriceb.php?qty=" + $("#quantityb").val() +"&p=" + $("#price1b").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashb") {
$("#Cashb").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 3rd Line -->
<script>
$("#quantityb").bind("change", function(e){
$.getJSON("getsumb.php?qty=" + $("#quantityb").val() + "&?aID=" + $("#articleIDb").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashb") {
$("#Cashb").val(item.value);
}
});
});
});
</script>

<!-- End 3rd Line -->
<!-- Begin of 4th line -->
<!--  from 3rd article to 3rd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDc, #sizec').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 3rd size to the 4th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sizec, #articleIDd').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDc").bind("change", function(e){
$.getJSON("getarticlec.php?aID=" + $("#articleIDc").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricec") {
$("#pricec").val(item.value);
} else if (item.field == "price1c") {
$("#price1c").val(item.value);
} else if (item.field == "diff4") {
$("#diff4").val(item.value);
} else if (item.field == "Cashc") {
$("#Cashc").val(item.value);
} else if (item.field == "quantityc") {
$("#quantityc").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 4th line with the price1b -->
<script>
$("#quantityc").bind("change", function(e){
$.getJSON("getmultiplepricec.php?qty=" + $("#quantityc").val() +"&p=" + $("#price1c").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashc") {
$("#Cashc").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 4th Line -->
<script>
$("#quantityc").bind("change", function(e){
$.getJSON("getsumc.php?qty=" + $("#quantityc").val() + "&?aID=" + $("#articleIDc").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashc") {
$("#Cashc").val(item.value);
}
});
});
});
</script>
<!-- End of the 4th line -->

<!-- Begin of 5th line -->
<!--  from 5th article to 5th size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDd, #sized').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 5rd size to the 6th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sized, #articleIDe').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDd").bind("change", function(e){
$.getJSON("getarticled.php?aID=" + $("#articleIDd").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "priced") {
$("#priced").val(item.value);
} else if (item.field == "price1d") {
$("#price1d").val(item.value);
} else if (item.field == "diff5") {
$("#diff5").val(item.value);
} else if (item.field == "Cashd") {
$("#Cashd").val(item.value);
} else if (item.field == "quantityd") {
$("#quantityd").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 5th line with the price1b -->
<script>
$("#quantityd").bind("change", function(e){
$.getJSON("getmultiplepriced.php?qty=" + $("#quantityd").val() +"&p=" + $("#price1d").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashd") {
$("#Cashd").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 5th Line -->
<script>
$("#quantityd").bind("change", function(e){
$.getJSON("getsumd.php?qty=" + $("#quantityd").val() + "&?aID=" + $("#articleIDd").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashd") {
$("#Cashd").val(item.value);
}
});
});
});
</script>
<!-- End of the 5th line -->

<!-- Begin of 6th line 
<!--  from 6th article to 6th size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDe, #sizee').autotab_magic().autotab_filter('numeric');
});
</script>

<script>
$("#articleIDe").bind("change", function(e){
$.getJSON("getarticlee.php?aID=" + $("#articleIDe").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricee") {
$("#pricee").val(item.value);
} else if (item.field == "price1e") {
$("#price1e").val(item.value);
} else if (item.field == "diff6") {
$("#diff6").val(item.value);
} else if (item.field == "Cashe") {
$("#Cashe").val(item.value);
} else if (item.field == "quantitye") {
$("#quantitye").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 6th line with the price1e -->
<script>
$("#quantitye").bind("change", function(e){
$.getJSON("getmultiplepricee.php?qty=" + $("#quantitye").val() +"&p=" + $("#price1e").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashe") {
$("#Cashe").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 6th Line -->
<script>
$("#quantitye").bind("change", function(e){
$.getJSON("getsume.php?qty=" + $("#quantitye").val() + "&?aID=" + $("#articleIDe").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashe") {
$("#Cashe").val(item.value);
}
});
});
});
</script> 
<!-- End of the 6th line -->

<script>
// that script calculate the sum of all cash to be paid by the customer.
//First we get all the text boxs that have the class="tot" 
// After that we use the function calculateSum()
    $(document).ready(function(){
 
        //iterate through each textboxes and add keyup
        //handler to trigger sum event
        $(".tot").each(function() {
 
            $(this).keyup(function(){
                calculateSum();
            });
        });
 
    });
 
 // calculateSum function
    function calculateSum() {
 
        var sum = 0;
        //iterate through each textboxes and add the values
        $(".tot").each(function() {
 
            //add only if the value is number
            if(!isNaN(this.value) && this.value.length!=0) {
                sum += parseFloat(this.value);
            }
 
        });
        //.toFixed() method will roundoff the final sum to 2 decimal places
        $("#sum").html(sum.toFixed(2));
    }
</script>
</HEAD>
<BODY onLoad="document.articleForm.articleID.focus()">
<center>
<table>
<tr align="center">
<form name="articleForm" action="<?php $_SERVER['PHP_SELF'];?>" method="post">
<td colspan="7">Facture Number:<?php echo $billid;?>
<input type="submit" name="articleForm-total" id="articleForm-total" value="total" onClick="total(this.form,6)">
<input type="submit" name="articleForm-reset" id="articleForm-reset" value="submit">
<input type="reset" name="articleForm-reset" id="articleForm-reset" value="reset">

</form>
</tr>

<tr align="center">
<td><label for="articleID">Article </label></td>
<td><label for="price">O Price</label></td>
<td><label for="price1">D price</label></td>
<td><label for="Difference">Difference</label></td>
<td><label for="size">Size:</label></td>
<td><label for="quantity">Qty:</label></td>
<td><label for="Cash">Cash:</label></td>
</tr>


<tr><form name="form1" method="post">
<td><input name="articleID" id="articleID" size="5" maxlength="7"></td>
<td><input name="price" id="price" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1" id="price1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff1" id="diff1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="size" id="size" size="5" maxlength="3"></td>
<td><input name="quantity0" id="quantity0" size="5" maxlength="3"></td>
<td><input name="Cash0" id="Cash0" size="20" maxlength="255" class="tot"></td>
<td><input name="form1-reset" type="reset" id="form1-reset" value="reset"></td>
</form></tr>


<tr><form name="form2" method="post">
<td><input name="articleIDa" id="articleIDa" size="5" maxlength="7"></td>
<td><input name="pricea" id="pricea" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1a" id="price1a" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff2" id="diff2" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizea" id="sizea" size="5" maxlength="3"></td>
<td><input name="quantity1" id="quantity1" size="5" maxlength="3"></td>
<td><input name="Cash1" id="Cash1" size="20" maxlength="255" class="tot"></td>
<td><input name="form2-reset" type="reset" id="form2-reset" value="reset"></td>
</form></tr>


<tr><form name="form3" method="post">
<td><input name="articleIDb" id="articleIDb" size="5" maxlength="7"></td>
<td><input name="priceb" id="priceb" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1b" id="price1b" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff3" id="diff3" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizeb" id="sizeb" size="5" maxlength="3"></td>
<td><input name="quantity2" id="quantity2" size="5" maxlength="3"></td>
<td><input name="Cash2" id="Cash2" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" name="form3-reset" id="form3-reset" value="reset"></td>
</form></tr>


<tr><form name="form4" method="post">
<td><input name="articleIDc" id="articleIDc" size="5" maxlength="7"></td>
<td><input name="pricec" id="pricec" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1c" id="price1c" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff4" id="diff4" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizec" id="sizec" size="5" maxlength="3"></td>
<td><input name="quantity3" id="quantity3" size="5" maxlength="3"></td>
<td><input name="Cash3" id="Cash3" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" name="form4-reset" id="form4-reset" value="reset"></td>
</form></tr>


<tr><form name="form5" method="post">
<td><input name="articleIDd" id="articleIDd" size="5" maxlength="7"></td>
<td><input name="priced" id="priced" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1d" id="price1d" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff5" id="diff5" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sized" id="sized" size="5" maxlength="3"></td>
<td><input name="quantity4" id="quantity4" size="5" maxlength="3"></td>
<td><input name="Cash4" id="Cash4" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" name="form5-reset" id="form5-reset" value="reset"></td>
</form></tr>


<tr><form name="form6" method="post">
<td><input name="articleIDe" id="articleIDe" size="5" maxlength="7"></td>
<td><input name="pricee" id="pricee" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1e" id="price1e" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff6" id="diff6" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizee" id="sizec" size="5" maxlength="3"></td>
<td><input name="quantity5" id="quantity5" size="5" maxlength="3"></td>
<td><input name="Cash5" id="Cash5" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" name="form6-reset" id="form6-reset" value="reset"></td>
</form></tr>

<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td align="right">Total :</td>
<td align="center"><span id="sum">0</span></td>
<td></td>
</tr>
</table>
<div id="images"></div>




</center>
</BODY>
<script type="text/javascript">
$("#articleID").bind("change", function(e){
$.getJSON("getarticle2.php?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>
</HTML>
