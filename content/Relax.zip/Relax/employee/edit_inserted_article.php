<?php
ob_start();
require("../config/connect.php");
include_once("queiresMenu.php");
$id=$_GET[id];

$query=mysql_query("SELECT * 
FROM  `inserted_article` 
WHERE  `inserted_id` ='$id'
LIMIT 0 , 30");
while($result=mysql_fetch_array($query)){
$lastq1=$result[qty1];
$lastq2=$result[qty2];
$lastq3=$result[qty3];
$lastq4=$result[qty4];
$lastq5=$result[qty5];	
$lastq6=$result[qty6];
$lastq7=$result[qty7];
$lastq8=$result[qty8];
$lastq9=$result[qty9];
$lastq10=$result[qty10];	
$lastq11=$result[qty11];
$lastq12=$result[qty12];
$lastq13=$result[qty13];
$article=$result[inserted_article];

}

if(isset($_POST['submit'])){
$pos1=$_POST[qtya];
$pos2=$_POST[qtyb];
$pos3=$_POST[qtyc];
$pos4=$_POST[qtyd];
$pos5=$_POST[qtye];
$pos6=$_POST[qtyf];
$pos7=$_POST[qtyg];
$pos8=$_POST[qtyh];
$pos9=$_POST[qtyi];
$pos10=$_POST[qtyj];
$pos11=$_POST[qtyk];
$pos12=$_POST[qtyl];
$pos13=$_POST[qtym];
$updatequery=mysql_query("UPDATE  `inserted_article` SET  `qty1` =  '$pos1',
`qty2` =  '$pos2',
`qty3` =  '$pos3',
`qty4` =  '$pos4',
`qty5` =  '$pos5',
`qty6` =  '$pos6',
`qty7` =  '$pos7',
`qty8` =  '$pos8',
`qty9` =  '$pos9',
`qty10` =  '$pos10',
`qty11` =  '$pos11',
`qty12` =  '$pos12',
`qty13` =  '$pos13' WHERE  `inserted_article`.`inserted_id` = '$id' LIMIT 1");

}
?>
<html>
<body onLoad="document.updateinsertedform.qtya.focus()">
<form name="updateinsertedform" action="<?php $_SERVER['PHP_SELF']?>" method="post">

<table width="497" border="1" cellpadding="0" cellspacing="0" align="center">
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 1</td>
      <td width="35">18</td>
      <td width="35	">19</td>
      <td width="35">20</td>
      <td width="35">21</td>
      <td width="35">22</td>
      <td width="35">23</td>
      <td width="35">24</td>
      <td width="35">25</td>
      <td width="35">26</td>
      <td width="35">27</td>
      <td width="35">28</td>
      <td width="35">29</td>
      <td width="35">30</td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 2</td>
      <td width="35">25</td>
      <td width="35">26</td>
      <td width="35">27</td>
      <td width="35">28</td>
      <td width="35">29</td>
      <td width="35">30</td>
      <td width="35">31</td>
      <td width="35">32</td>
      <td width="35">33</td>
      <td width="35">34</td>
      <td width="35">35</td>
      <td width="35">36</td>
      <td width="35">37</td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie3/4/5</td>
      <td width="35">35</td>
      <td width="35">36</td>
      <td width="35">37</td>
      <td width="35">38</td>
      <td width="35">39</td>
      <td width="35">40</td>
      <td width="35">41</td>
      <td width="35">42</td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
      <td width="35"></td>
    </tr>
    <tr bgcolor="#66CCCC" align="center">
      <td width="77">Serie 7</td>
      <td width="35">39</td>
      <td width="35">40</td>
      <td width="35">41</td>
      <td width="35">41.5</td>
      <td width="35">42</td>
      <td width="35">42.5</td>
      <td width="35">43</td>
      <td width="35">43.5</td>
      <td width="35">44</td>
      <td width="35">45</td>
      <td width="35">46</td>
      <td width="35">47</td>
      <td width="35">48</td>
    </tr>
    <tr>
      <td width="77"><input name="Editform" id="GetArticles" size="5" value="<?php echo $article;?>" readonly="readonly"></td>
      <td width="35"><input type="text" name="qtya" id="qtya" size="1" value="<?php echo $lastq1;?>"></td>
      <td width="35"><input type="text" name="qtyb" id="qtyb" size="1" value="<?php echo $lastq2;?>"></td>
      <td width="35"><input type="text" name="qtyc" id="qtyc" size="1" value="<?php echo $lastq3;?>"></td>
      <td width="35"><input type="text" name="qtyd" id="qtyd" size="1" value="<?php echo $lastq4;?>"></td>
      <td width="35"><input type="text" name="qtye" id="qtye" size="1" value="<?php echo $lastq5;?>"></td>
      <td width="35"><input type="text" name="qtyf" id="qtyf" size="1" value="<?php echo $lastq6;?>"></td>
      <td width="35"><input type="text" name="qtyg" id="qtyg" size="1" value="<?php echo $lastq7;?>"></td>
      <td width="35"><input type="text" name="qtyh" id="qtyh" size="1" value="<?php echo $lastq8;?>"></td>
      <td width="35"><input type="text" name="qtyi" id="qtyi" size="1" value="<?php echo $lastq9;?>"></td>
      <td width="35"><input type="text" name="qtyj" id="qtyj" size="1" value="<?php echo $lastq10;?>"></td>
      <td width="35"><input type="text" name="qtyk" id="qtyk" size="1" value="<?php echo $lastq11;?>"></td>
      <td width="35"><input type="text" name="qtyl" id="qtyl" size="1" value="<?php echo $lastq12;?>"></td>
      <td width="35"><input type="text" name="qtym" id="qtym" size="1" value="<?php echo $lastq13;?>"></td>
    </tr>
    <tr> <td><input type="submit" name="submit" value="Update"></td></tr>
  </table>
  
</form>
</html>
