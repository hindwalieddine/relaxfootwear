<?php
error_reporting(E_ALL ^ E_NOTICE);
function check_login_admin()
{
	session_start();
if($_SESSION['check_login_emp'] != 'already_login_emp')
{
$LoginLink = "<a href=\"../index.php\">Login</a>";
echo "your time is out click here to $LoginLink";
exit();
}
else{};
}//function







function login_emp(){
	session_start();
require_once("config/connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	
foreach($_POST as $key => $value)
	{
	     $_POST[$key] = mysql_real_escape_string($value);
	}
	
	
	$user = $_POST[usertxt];
	$pass = $_POST[passtxt];
	$login_succes=0;
	
$select_admins=mysql_query("SELECT * FROM `emp`");
@mysql_query($select_admins);
while($row1 = mysql_fetch_array($select_admins)){
$login_succes	=	2;
$user_right 	=	$row1['emp_name'];
$pass_right	    =	$row1['emp_pass'];
$admin_id    	=	$row1['emp_id'];

	if ($user == $user_right && $pass == $pass_right)
	{ 
		$login_succes=1;
		$_SESSION['check_login_emp']   =  "already_login_emp" ;
		
		?> <script type="text/javascript"> window.location="employee/home.php"; </script> <?php
		
	}
	
  }
 if($login_succes == 2)
  { 
    $_SESSION['invalid_pass1']="invalid_pass1";
	 ?> <script type="text/javascript"> window.location="index.php"; </script> <?php
	 }
    
   }
   
}//function

function checkexistarticle($article){
	// Check to see if the article is already created or not!

	$count=mysql_query("SELECT COUNT( * ) AS nb
FROM  `article` 
WHERE  `article`.`article_id` =  '$article' LIMIT 1;");
$result=mysql_fetch_array($count);
$nb=$result['nb'];
//echo "nb: ".$nb; echo "<br>";
if($nb==0){?>
<script language="javascript">
	alert("You Need to create the article before inserting");
	location = 'recuRelax.php';
	</script>
<?php
	exit;
}
	
}

function checkarticle1($article){
		// Check to see if the article is already created or not!

	$count=mysql_query("SELECT COUNT( * ) AS nb
FROM  `article` 
WHERE  `article`.`article_id` =  '$article' LIMIT 1;");
$result=mysql_fetch_array($count);
$nb=$result['nb'];
//echo "nb: ".$nb; echo "<br>";
if($nb==0){?>
<script language="javascript">
	alert("The article ".<?php echo $article;?>."does not existe in stock!!");
	location = 'vente_3.php';
	</script>
<?php
	exit;
}
	

}
// Check if the article is inserted at the same day! If yes redirect to the page recuRelax2.php with the same inserted articles!
function checkifarticleinsertedsameday($article,$date){
	
$count=mysql_query("SELECT COUNT( * ) AS n
FROM  `inserted_article` 
WHERE  `inserted_article` =  '$article'
AND `inserted_date` = '$date';");
$result=mysql_fetch_array($count);
$n=$result['n'];
//echo "nb: ".$nb; echo "<br>";
if($n>0){?>
<script language="javascript">
	alert("You did insert this article in this date");
	location = 'recuRelax2.php?id=<?php echo $article;?>&d=<?php echo selecteddate;?>&q=<?php echo $totalquantity;?>&q1=<?php echo $qtya;?>&q2=<?php echo $qtyb;?>&q3=<?php echo $qtyc;?>&q4=<?php echo $qtyd;?>&q5=<?php echo $qtye;?>&q6=<?php echo $qtyf;?>&q7=<?php echo $qtyg;?>&q8=<?php echo $qtyh;?>&q9=<?php echo $qtyi;?>&q10=<?php echo $qtyj;?>&q11=<?php echo $qtyk;?>&q12=<?php echo $qtyl;?>&q13=<?php echo $qtym;?>&qty1=<?php echo $qty1;?>&qty2=<?php echo $qty2;?>&qty3=<?php echo $qty3;?>&qty4=<?php echo $qty4;?>&qty5=<?php echo $qty5;?>&qty6=<?php echo $qty6;?>&qty7=<?php echo $qty7;?>&qty8=<?php echo $qty8;?>&qty9=<?php echo $qty9;?>&qty10=<?php echo $qty10;?>&qty11=<?php echo $qty11;?>&qty12=<?php echo $qty12;?>&qty13=<?php echo $qty13;?>';
	</script>
<?php
	exit;
}
}

// Insert into Inserted_Article table
function InsertIntoInsertedArticle($article,$date,$q1,$q2,$q3,$q4,$q5,$q6,$q7,$q8,$q9,$q10,$q11,$q12,$q13){
$Insertquery=mysql_query("INSERT INTO  `inserted_article` (  `inserted_id` ,  `inserted_article` ,  `inserted_date` ,  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` ) 
VALUES (NULL ,  '$article',  '$date',  '$q1',  '$q2',  '$q3',  '$q4',  '$q5',  '$q6',  '$q7',  '$q8',  '$q9',  '$q10',  '$q11',  '$q12',  '$q13')");	
	
}

?>