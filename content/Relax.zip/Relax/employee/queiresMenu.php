<html>
<table width="826" align="center" bgcolor="#3399FF">
<tr><td width="98" height="30"><a href="home.php">Home</a></td>
<td width="262"><a href="Get_All_inserted_articles-mazbouta.php">See Recu</a></td>
<td><a href="RelaxInventaire.php">Relax Inventaire</a></td>
<td><a href="SeeVente.php">Relax Vente</a></td>
<td width="117"><a href="transfert.php">Transfer</a></td>
<td width="106"><a href="logout.php">Logout</a></td>

</tr>
</table>
</html>