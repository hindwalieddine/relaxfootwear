<?php
ob_start();
include_once("menu.php");
include_once("../config/connect.php");
?>
<HTML>
<HEAD>
<style type="text/css">
body{
background-repeat:no-repeat;
font-family: Trebuchet MS, Lucida Sans Unicode, Arial, sans-serif;
height:100%;
background-color: #FFF;
margin:0px;
padding:0px;
background-image:url('/images/heading3.gif');
background-repeat:no-repeat;
padding-top:85px;
}

fieldset{
width:500px;
margin-left:10px;
}

</style>
<!-- script type="text/javascript" src="jquery-1.5.1.min.js"></script -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.autotab.js"></script>

</HEAD>
<BODY>
<center>
<table>
<form name="articleForm" action="ajax-article_lookup.html" method="post">
<tr align="center">
<td colspan="7">Facture</td>
</tr>

<tr align="center">
<td><label for="articleID">Article </label></td>
<td><label for="price">O Price</label></td>
<td><label for="price1">D price</label></td>
<td><label for="Difference">Difference</label></td>
<td><label for="size">Size:</label></td>
<td><label for="quantity">Qty:</label></td>
<td><label for="Cash">Cash:</label></td>
</tr>

<form name="form1">
<tr>
<td><input name="articleID" id="articleID" size="5" maxlength="7"></td>
<td><input name="price" id="price" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1" id="price1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff1" id="diff1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="size" id="size" size="5" maxlength="3"></td>
<td><input name="quantity" id="quantity" size="5" maxlength="3"></td>
<td><input name="Cash" id="Cash" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" id="reset" value="reset"></td>
</tr>
</form>
<form name="form2">
<tr>
<td><input name="articleIDa" id="articleIDa" size="5" maxlength="7"></td>
<td><input name="pricea" id="pricea" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1a" id="price1a" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff2" id="diff2" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizea" id="sizea" size="5" maxlength="3"></td>
<td><input name="quantitya" id="quantitya" size="5" maxlength="3"></td>
<td><input name="Casha" id="Casha" size="20" maxlength="255" class="tot"></td>
<td><input type="reset" id="reset" value="reset"></td>
</tr>
</form>

<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td align="right">Total :</td>
<td align="center"><span id="sum">0</span></td>
<td></td>
</tr>
<tr>


</tr>
</table>
<input type="submit" id="submit" value="submit">
<input type="reset" id="reset" value="reset">

</form>




<div id="images"></div>

<!--  from 1st article to 1st size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleID, #size').autotab_magic().autotab_filter('numeric');
});
</script>
<!--  from 1st size to 1st quantity  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#size, #quantity').autotab_magic().autotab_filter('numeric');
});
</script>

<!--when we click on the 1st article -->
<script type="text/javascript">
$("#articleID").bind("change", function(e){
$.getJSON("getarticle2.php?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "price2") {
$("#price2").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 1st line   price1 -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getmultipleprice.php?qty=" + $("#quantity").val() +"&p=" + $("#price1").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "price2") {
$("#price2").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<script>
$("#articleIDa").bind("change", function(e){
$.getJSON("getarticlea.php?aID=" + $("#articleIDa").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricea") {
$("#pricea").val(item.value);
} else if (item.field == "price1a") {
$("#price1a").val(item.value);
} else if (item.field == "price2a") {
$("#price2a").val(item.value);
}
});
});
});
</script>
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getsum.php?qty=" + $("#quantity").val() + "&?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "total") {
$("#total").val(item.value);
}
});
});
});
</script>

<SCRIPT language=javascript type="text/javascript">
function calculate() {
 
document.form1.elements.total.value = (document.form1.elements.price1.value * document.form1.elements.quantity.value);
}
</script>

<script>
// that script calculate the sum of all cash to be paid by the customer.
//First we get all the text boxs that have the class="tot" 
// After that we use the function calculateSum()
    $(document).ready(function(){
 
        //iterate through each textboxes and add keyup
        //handler to trigger sum event
        $(".tot").each(function() {
 
            $(this).keyup(function(){
                calculateSum();
            });
        });
 
    });
 
 // calculateSum function
    function calculateSum() {
 
        var sum = 0;
        //iterate through each textboxes and add the values
        $(".tot").each(function() {
 
            //add only if the value is number
            if(!isNaN(this.value) && this.value.length!=0) {
                sum += parseFloat(this.value);
            }
 
        });
        //.toFixed() method will roundoff the final sum to 2 decimal places
        $("#sum").html(sum.toFixed(2));
    }
</script>

</center>
</BODY>
</HTML>