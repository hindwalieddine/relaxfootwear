<?php
error_reporting(0);
ob_start();
include_once("menu.php");
include_once("../config/connect.php");
include_once("include/function.php");
$date=date('Y-m-d');
if(isset($_POST['submit'])){   

	?>
    <!--<script>
	var FirstArticle=articleForm.articleID.value;
	document.writeln(FirstArticle);
	</script> -->
    
    <?php
	$FirstArticle=$_POST['articleID'];
	$SecondArticle=$_POST['articleIDa'];
	$ThirdArticle=$_POST['articleIDb'];
	$ForthArticle=$_POST['articleIDc'];
    $FifthArticle=$_POST['articleIDd'];
	$SixthArticle=$_POST['articleIDe'];
	
	$FirstSize=$_POST['size'];
	$SecondSize=$_POST['sizea'];
	$ThirdSize=$_POST['sizeb'];
	$ForthSize=$_POST['sizec'];
	$FifthSize=$_POST['sized'];
	$SixthSize=$_POST['sizee'];
	
	$FirstQty=$_POST['quantity'];
	$SecondQty=$_POST['quantitya'];
	$ThirdQty=$_POST['quantityb'];
	$ForthQty=$_POST['quantityc'];
	$FifthQty=$_POST['quantityd'];
	$SixthQty=$_POST['quantitye'];
	
	$FirstCash=$_POST['Cash'];
	$SecondCash=$_POST['Casha'];
	$ThirdCash=$_POST['Cashb'];
	$ForthCash=$_POST['Cashc'];
	$FifthCash=$_POST['Cashd'];
	$SixthCash=$_POST['Cashe'];
	
	/*if(($FirstArticle==NULL) && ($SecondArticle==NULL) && ($ThirdArticle==NULL) && ($ForthArticle==NULL) && ($FifthArticle==NULL) && ($SixthArticle==NULL)){}
	if($FirstArticle){
		 if($FirstQty==NULL){
			 ?>
			  <script>
			  alert("Please insert a quantity for the 1st artilce");
			  	</script>
                <?php
				        }
		 if($FirstCash==NULL){ ?> 
         <script>
		 alert("Please enter the 1st cash");
		 </script> 
		 <?php }
	                 }*/
	
	
		$InsertFacture=mysql_query("INSERT INTO  `facture` (  `fact_id` ,  `fact_date` ) VALUES ( NULL ,  '$date' ); ");
	
		echo "FirstArticle ".$_POST['articleID']; echo "<br>";  echo "FirstSize ". $FirstSize; echo "<br>";  echo "FirstQty ". $FirstQty; echo "<br>";  echo "FirstCash ". $FirstCash; 
		
	if (($FirstArticle!=NULL)&&($FirstSize!=NULL)&&($FirstQty!=NULL)&&($FirstCash!=NULL)){ 
	$retour_total=mysql_query("SELECT MAX(fact_id) AS fid FROM facture "); 
    $donnees_total=mysql_fetch_assoc($retour_total);
	$fid=$donnees_total['fid'];
	
	
/*	//checkarticle1($FirstArticle);
/	if((($FirstQty!=180)&&($FirstQty!=190)&&($FirstQty!=200)&&($FirstQty!=210)&&($FirstQty!=220)&&($FirstQty!=230)&&($FirstQty!=240)&&($FirstQty!=250)&&($FirstQty!=260)&&($FirstQty!=270)&&($FirstQty!=280)&&($FirstQty!=290)&&($FirstQty!=300)&&($FirstQty!=310)&&($FirstQty!=320)&&($FirstQty!=330)&&($FirstQty!=340)&&($FirstQty!=350)&&($FirstQty!=360)&&($FirstQty!=370)&&($FirstQty!=380)&&($FirstQty!=390)&&($FirstQty!=400)&&($FirstQty!=410)&&($FirstQty!=415)&&($FirstQty!=420)&&($FirstQty!=425)&&($FirstQty!=430)&&($FirstQty!=435)&&($FirstQty!=440)&&($FirstQty!=450)&&($FirstQty!=460)&&($FirstQty!=470)&&($FirstQty!=480)) || (($SecondQty!=180)&&($SecondQty!=190)&&($SecondQty!=200)&&($SecondQty!=210)&&($SecondQty!=220)&&($SecondQty!=230)&&($SecondQty!=240)&&($SecondQty!=250)&&($SecondQty!=260)&&($SecondQty!=270)&&($SecondQty!=280)&&($SecondQty!=290)&&($SecondQty!=300)&&($SecondQty!=310)&&($SecondQty!=320)&&($SecondQty!=330)&&($SecondQty!=340)&&($SecondQty!=350)&&($SecondQty!=360)&&($SecondQty!=370)&&($SecondQty!=380)&&($SecondQty!=390)&&($SecondQty!=400)&&($SecondQty!=410)&&($SecondQty!=415)&&($SecondQty!=420)&&($SecondQty!=425)&&($SecondQty!=430)&&($SecondQty!=435)&&($SecondQty!=440)&&($SecondQty!=450)&&($SecondQty!=460)&&($SecondQty!=470)&&($SecondQty!=480)) ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 1st line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                     }*/
									 
									 
		if(($FirstArticle<2000000)&&($FirstSize==180)){
			// serie1
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '', '$fid' ); ");	                                 }//end if size=18
	if(($FirstArticle<2000000)&&($FirstSize==190)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES  ( NULL ,  '$FirstArticle', '$FirstCash', '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '', '$fid' ); ");	                             }  //end if size=19
			if(($FirstArticle<2000000)&&($FirstSize==200)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstCash','',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FirstArticle<2000000)&&($FirstSize==210)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FirstArticle<2000000)&&($FirstSize==220)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstCash', '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FirstArticle<2000000)&&($FirstSize==230)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FirstArticle<2000000)&&($FirstSize==240)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FirstArticle<2000000)&&($FirstSize==250)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstCash','',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FirstArticle<2000000)&&($FirstSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FirstArticle<2000000)&&($FirstSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FirstArticle<2000000)&&($FirstSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FirstArticle<2000000)&&($FirstSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FirstArticle<2000000)&&($FirstSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty' , '$fid' ); ");	                             } //end if size=30
	//end serie1
      
	  		if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FirstArticle<3000000)&&($FirstArticle>199999)&&($FirstSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FirstArticle<6000000)&&($FirstArticle>299999)&&($FirstSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstCash', '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle',  '$FirstCash', '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FirstArticle<8000000)&&($FirstArticle>699999)&&($FirstSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FirstQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($FirstArticle<7000000)&&($FirstArticle>599999) || ($FirstArticle<9000000)&&($FirstArticle>799999)) &&($FirstSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FirstArticle', '$FirstCash', '$FirstQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                                                                                         }//end if 1st inserted line (1st article)
																						 
	if (($SecondArticle!=NULL)&&($SecondSize!=NULL)&&($SecondQty!=NULL)&&($SecondCash!=NULL)){ 
	
/*	if(  ($SecondQty<180) || (($SecondQty>180)&&($SecondQty<190)) || (($SecondQty>190)&&($SecondQty<200)) || (($SecondQty>200)&&($SecondQty<210)) || (($SecondQty>210)&&($SecondQty<220)) || (($SecondQty>220)&&($SecondQty<230)) || (($SecondQty>230)&&($SecondQty<240)) || (($SecondQty>240)&&($SecondQty<250)) || (($SecondQty>250)&&($SecondQty<260)) || (($SecondQty>260)&&($SecondQty<270)) || (($SecondQty>270)&&($SecondQty<280)) || (($SecondQty>280)&&($SecondQty<290)) || (($SecondQty>290)&&($SecondQty<300)) || (($SecondQty>300)&&($SecondQty<310)) || (($SecondQty>310)&&($SecondQty<320)) || (($SecondQty>320)&&($SecondQty<330)) || (($SecondQty>330)&&($SecondQty<340)) || (($SecondQty>340)&&($SecondQty<350)) || (($SecondQty>350)&&($SecondQty<360)) || (($SecondQty>360)&&($SecondQty<370)) || (($SecondQty>370)&&($SecondQty<380)) || (($SecondQty>380)&&($SecondQty<390)) || (($SecondQty>390)&&($SecondQty<400)) || (($SecondQty>400)&&($SecondQty<410)) || (($SecondQty>410)&&($SecondQty<415)) || (($SecondQty>415)&&($SecondQty<420)) || (($SecondQty>420)&&($SecondQty<425)) || (($SecondQty>425)&&($SecondQty<430)) || (($SecondQty>430)&&($SecondQty<435)) || (($SecondQty>435)&&($SecondQty<440)) || (($SecondQty>440)&&($SecondQty<450)) || (($SecondQty>450)&&($SecondQty<460)) || (($SecondQty>460)&&($SecondQty<470)) || (($SecondQty<470)&&($SecondQty>480))  ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 2nd line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                    }
*/

		if(($SecondArticle<2000000)&&($SecondSize==180)){
			// serie1
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SecondArticle<2000000)&&($SecondSize==190)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SecondArticle<2000000)&&($SecondSize==200)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SecondArticle<2000000)&&($SecondSize==210)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SecondArticle<2000000)&&($SecondSize==220)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SecondArticle<2000000)&&($SecondSize==230)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SecondArticle<2000000)&&($SecondSize==240)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SecondArticle<2000000)&&($SecondSize==250)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle',  '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SecondArticle<2000000)&&($SecondSize==260)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SecondArticle<2000000)&&($SecondSize==270)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SecondArticle<2000000)&&($SecondSize==280)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SecondArticle<2000000)&&($SecondSize==290)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SecondArticle<2000000)&&($SecondSize==300)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty' , '$fid' ); ");	                             } //end if size=30
            //end serie1     
		
	  		if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle',  '$SecondCash', '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle',  '$SecondCash','',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SecondArticle<3000000)&&($SecondArticle>199999)&&($SecondSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SecondArticle<6000000)&&($SecondArticle>299999)&&($SecondSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle',  '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SecondArticle<8000000)&&($SecondArticle>699999)&&($SecondSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle',  '$SecondCash', '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SecondQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($SecondArticle<7000000)&&($SecondArticle>599999) || ($SecondArticle<9000000)&&($SecondArticle>799999)) &&($SecondSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SecondArticle', '$SecondCash', '$SecondQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                       
                                                                                         }//end if 2nd inserted line (2nd article)																						 
																						 
																						 
		if (($ThirdArticle!=NULL)&&($ThirdSize!=NULL)&&($ThirdQty!=NULL)&&($ThirdCash!=NULL)){ 
		
/*	if(($ThirdQty!=180)&&($ThirdQty!=190)&&($ThirdQty!=200)&&($ThirdQty!=210)&&($ThirdQty!=220)&&($ThirdQty!=230)&&($ThirdQty!=240)&&($ThirdQty!=250)&&($ThirdQty!=260)&&($ThirdQty!=270)&&($ThirdQty!=280)&&($ThirdQty!=290)&&($ThirdQty!=300)&&($ThirdQty!=310)&&($ThirdQty!=320)&&($ThirdQty!=330)&&($ThirdQty!=340)&&($ThirdQty!=350)&&($ThirdQty!=360)&&($ThirdQty!=370)&&($ThirdQty!=380)&&($ThirdQty!=390)&&($ThirdQty!=400)&&($ThirdQty!=410)&&($ThirdQty!=415)&&($ThirdQty!=420)&&($ThirdQty!=425)&&($ThirdQty!=430)&&($ThirdQty!=435)&&($ThirdQty!=440)&&($ThirdQty!=450)&&($ThirdQty!=460)&&($ThirdQty!=470)&&($ThirdQty!=480) ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 3rd line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                     }*/ 

		if(($ThirdArticle<2000000)&&($ThirdSize==180)){
			// serie1
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash', '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ThirdArticle<2000000)&&($ThirdSize==190)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ThirdArticle<2000000)&&($ThirdSize==200)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ThirdArticle<2000000)&&($ThirdSize==210)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ThirdArticle<2000000)&&($ThirdSize==220)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ThirdArticle<2000000)&&($ThirdSize==230)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ThirdArticle<2000000)&&($ThirdSize==240)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ThirdArticle<2000000)&&($ThirdSize==250)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ThirdArticle<2000000)&&($ThirdSize==260)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ThirdArticle<2000000)&&($ThirdSize==270)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ThirdArticle<2000000)&&($ThirdSize==280)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ThirdArticle<2000000)&&($ThirdSize==290)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ThirdArticle<2000000)&&($ThirdSize==300)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty' , '$fid' ); ");	                             } //end if size=30
            //end serie1     
			

	  		if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ThirdArticle<3000000)&&($ThirdArticle>199999)&&($ThirdSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ThirdArticle<6000000)&&($ThirdArticle>299999)&&($ThirdSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ThirdArticle<8000000)&&($ThirdArticle>699999)&&($ThirdSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ThirdQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($ThirdArticle<7000000)&&($ThirdArticle>599999) || ($ThirdArticle<9000000)&&($ThirdArticle>799999)) &&($ThirdSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ThirdArticle', '$ThirdCash',  '$ThirdQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                       
                  
				                                                                         }//end if 3rd inserted line (3rd article)																						 
			if (($ForthArticle!=NULL)&&($ForthSize!=NULL)&&($ForthQty!=NULL)&&($ForthCash!=NULL)){ 
		
/*	if(($ForthQty!=180)&&($ForthQty!=190)&&($ForthQty!=200)&&($ForthQty!=210)&&($ForthQty!=220)&&($ForthQty!=230)&&($ForthQty!=240)&&($ForthQty!=250)&&($ForthQty!=260)&&($ForthQty!=270)&&($ForthQty!=280)&&($ForthQty!=290)&&($ForthQty!=300)&&($ForthQty!=310)&&($ForthQty!=320)&&($ForthQty!=330)&&($ForthQty!=340)&&($ForthQty!=350)&&($ForthQty!=360)&&($ForthQty!=370)&&($ForthQty!=380)&&($ForthQty!=390)&&($ForthQty!=400)&&($ForthQty!=410)&&($ForthQty!=415)&&($ForthQty!=420)&&($ForthQty!=425)&&($ForthQty!=430)&&($ForthQty!=435)&&($ForthQty!=440)&&($ForthQty!=450)&&($ForthQty!=460)&&($ForthQty!=470)&&($ForthQty!=480) ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 4th line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                     }  */

		if(($ForthArticle<2000000)&&($ForthSize==180)){
			// serie1
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash', '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ForthArticle<2000000)&&($ForthSize==190)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ForthArticle<2000000)&&($ForthSize==200)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ForthArticle<2000000)&&($ForthSize==210)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ForthArticle<2000000)&&($ForthSize==220)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ForthArticle<2000000)&&($ForthSize==230)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ForthArticle<2000000)&&($ForthSize==240)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ForthArticle<2000000)&&($ForthSize==250)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ForthArticle<2000000)&&($ForthSize==260)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ForthArticle<2000000)&&($ForthSize==270)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ForthArticle<2000000)&&($ForthSize==280)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ForthArticle<2000000)&&($ForthSize==290)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ForthArticle<2000000)&&($ForthSize==300)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty' , '$fid' ); ");	                             } //end if size=30
            //end serie1    
			
	
	  		if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ForthArticle<3000000)&&($ForthArticle>199999)&&($ForthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article`  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article`   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article`  `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ForthArticle<6000000)&&($ForthArticle>299999)&&($ForthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($ForthArticle<8000000)&&($ForthArticle>699999)&&($ForthSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$ForthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($ForthArticle<7000000)&&($ForthArticle>599999) || ($ForthArticle<9000000)&&($ForthArticle>799999)) &&($ForthSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$ForthArticle', '$ForthCash',  '$ForthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                       
                                                                                         }//end if 3rd inserted line (3rd article)																					 
				if (($FifthArticle!=NULL)&&($FifthSize!=NULL)&&($FifthQty!=NULL)&&($FifthCash!=NULL)){ 
		
/*	if(($FifthQty!=180)&&($FifthQty!=190)&&($FifthQty!=200)&&($FifthQty!=210)&&($FifthQty!=220)&&($FifthQty!=230)&&($FifthQty!=240)&&($FifthQty!=250)&&($FifthQty!=260)&&($FifthQty!=270)&&($FifthQty!=280)&&($FifthQty!=290)&&($FifthQty!=300)&&($FifthQty!=310)&&($FifthQty!=320)&&($FifthQty!=330)&&($FifthQty!=340)&&($FifthQty!=350)&&($FifthQty!=360)&&($FifthQty!=370)&&($FifthQty!=380)&&($FifthQty!=390)&&($FifthQty!=400)&&($FifthQty!=410)&&($FifthQty!=415)&&($FifthQty!=420)&&($FifthQty!=425)&&($FifthQty!=430)&&($FifthQty!=435)&&($FifthQty!=440)&&($FifthQty!=450)&&($FifthQty!=460)&&($FifthQty!=470)&&($FifthQty!=480) ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 5th line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                     }  */

		if(($FifthArticle<2000000)&&($FifthSize==180)){
			// serie1
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash', '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FifthArticle<2000000)&&($FifthSize==190)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FifthArticle<2000000)&&($FifthSize==200)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FifthArticle<2000000)&&($FifthSize==210)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FifthArticle<2000000)&&($FifthSize==220)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FifthArticle<2000000)&&($FifthSize==230)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FifthArticle<2000000)&&($FifthSize==240)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FifthArticle<2000000)&&($FifthSize==250)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FifthArticle<2000000)&&($FifthSize==260)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FifthArticle<2000000)&&($FifthSize==270)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FifthArticle<2000000)&&($FifthSize==280)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FifthArticle<2000000)&&($FifthSize==290)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FifthArticle<2000000)&&($FifthSize==300)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty' , '$fid' ); ");	                             } //end if size=30
            //end serie1     
			
			
	  		if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FifthArticle<3000000)&&($FifthArticle>199999)&&($FifthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FifthArticle<6000000)&&($FifthArticle>299999)&&($FifthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($FifthArticle<8000000)&&($FifthArticle>699999)&&($FifthSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$FifthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($FifthArticle<7000000)&&($FifthArticle>599999) || ($FifthArticle<9000000)&&($FifthArticle>799999)) &&($FifthSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$FifthArticle', '$FifthCash',  '$FifthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                       
                                                                                         }//end if 3rd inserted line (3rd article)																									 
			if (($SixthArticle!=NULL)&&($SixthSize!=NULL)&&($SixthQty!=NULL)&&($SixthCash!=NULL)){ 
		
/*	if(($SixthQty!=180)&&($SixthQty!=190)&&($SixthQty!=200)&&($SixthQty!=210)&&($SixthQty!=220)&&($SixthQty!=230)&&($SixthQty!=240)&&($SixthQty!=250)&&($SixthQty!=260)&&($SixthQty!=270)&&($SixthQty!=280)&&($SixthQty!=290)&&($SixthQty!=300)&&($SixthQty!=310)&&($SixthQty!=320)&&($SixthQty!=330)&&($SixthQty!=340)&&($SixthQty!=350)&&($SixthQty!=360)&&($SixthQty!=370)&&($SixthQty!=380)&&($SixthQty!=390)&&($SixthQty!=400)&&($SixthQty!=410)&&($SixthQty!=415)&&($SixthQty!=420)&&($SixthQty!=425)&&($SixthQty!=430)&&($SixthQty!=435)&&($SixthQty!=440)&&($SixthQty!=450)&&($SixthQty!=460)&&($SixthQty!=470)&&($SixthQty!=480) ){ 
	?>
	<script>
	alert("you need to insert a valid size in the 6th line!!");
	window.history.back(); 


	</script>
	
	<?php
	exit;
                                     }
*/
		if(($SixthArticle<2000000)&&($SixthSize==180)){
			// serie1
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash', '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SixthArticle<2000000)&&($SixthSize==190)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SixthArticle<2000000)&&($SixthSize==200)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SixthArticle<2000000)&&($SixthSize==210)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SixthArticle<2000000)&&($SixthSize==220)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SixthArticle<2000000)&&($SixthSize==230)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SixthArticle<2000000)&&($SixthSize==240)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SixthArticle<2000000)&&($SixthSize==250)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SixthArticle<2000000)&&($SixthSize==260)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SixthArticle<2000000)&&($SixthSize==270)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SixthArticle<2000000)&&($SixthSize==280)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SixthArticle<2000000)&&($SixthSize==290)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SixthArticle<2000000)&&($SixthSize==300)){
	$Insert2ndArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty' , '$fid' ); ");	                             } //end if size=30
            //end serie1     
		
	  		if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==250)){
			// serie2
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==260)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==270)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==280)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==290)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==300)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==310)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==320)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==330)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==340)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==350)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SixthArticle<3000000)&&($SixthArticle>199999)&&($SixthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie2                                
	
		
		if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==350)){
			// serie3/4/5
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==360)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==370)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==380)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==390)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SixthArticle<6000000)&&($SixthArticle>299999)&&($SixthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25

	//end serie3/4/5
	
			if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==390)){
			// serie7
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
	if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==400)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=19
			if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==410)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=20
	if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==415)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=21
		if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==420)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=22
			if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==425)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=23
	if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==430)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                             }  //end if size=24	
				if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==435)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=25
	if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==440)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '',  '' , '$fid' ); ");	                             } //end if size=26
		if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==450)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '',  '' , '$fid' ); ");	                             } //end if size=27
			if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==460)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '',  '' , '$fid' ); ");	                                 }//end if size=28
	if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==470)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty',  '' , '$fid' ); ");	                             } //end if size=29
		if(($SixthArticle<8000000)&&($SixthArticle>699999)&&($SixthSize==480)){
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,    `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '$SixthQty' , '$fid' ); ");	                             } //end if size=30
	//end serie7
	
			if((($SixthArticle<7000000)&&($SixthArticle>599999) || ($SixthArticle<9000000)&&($SixthArticle>799999)) &&($SixthSize==350)){
			// serie6/8
	$Insert1stArticle=mysql_query("INSERT INTO  `vente_article` (  `vente_id` ,  `vente_article` , `cash`,   `qty1` ,  `qty2` ,  `qty3` ,  `qty4` ,  `qty5` ,  `qty6` ,  `qty7` ,  `qty8` ,  `qty9` ,  `qty10` ,  `qty11` ,  `qty12` ,  `qty13` , `fact_id` ) VALUES ( NULL ,  '$SixthArticle', '$SixthCash',  '$SixthQty',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '',  '' , '$fid' ); ");	                                 }//end if size=18
                           
	//end serie6/8
                       
                                                                                         }//end if 3rd inserted line (3rd article)																					 
                         }//end if

?>


<HTML>
<HEAD>
<style type="text/css">
body{
background-repeat:no-repeat;
font-family: Trebuchet MS, Lucida Sans Unicode, Arial, sans-serif;
height:100%;
background-color: #FFF;
margin:0px;
padding:0px;
background-image:url('/images/heading3.gif');
background-repeat:no-repeat;
padding-top:85px;
}

fieldset{
width:500px;
margin-left:10px;
}

</style>
<!-- script type="text/javascript" src="jquery-1.5.1.min.js"></script -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<!-- script to calculate automaticly... https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js -->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.autotab.js"></script>

<!-- <script type="text/javascript">
var a=articleForm.Cash.value; //set the value of first textbox.
var b=articleForm.Casha.value; //set the value of second textbox.
var c=articleForm.Cashb.value; //set the value of third textbox.
function app()
{
  
  if(articleForm.chk1.checked || articleForm.chk2.checked || articleForm.chk3.checked==true)
  {
    x=parseInt(a);
    y=parseInt(b);
    z=parseInt(c);
    sum=x+y+z;
    articleForm.txt3.value=sum;
  }
  else
    articleForm.txt3.value=0;   
}
</script> -->

<script type="text/javascript"> 

function checkqty() { 
  var msg = 'Invalid entry'; 
  var v = Number(document.articleForm.size.value); 
  if ($SecondQty<180) { msg = '1st'; } 
  if (($SecondQty>180)&&($SecondQty<190)) { msg = 'MEDIUM'; } 
  if (($SecondQty>190)&&($SecondQty<200)) { msg = 'HARD'; } 
  alert(msg); 
} 


</script> 

</HEAD>
<BODY onLoad="document.articleForm.articleID.focus()">
<center>
<form name="articleForm" onSubmit="<?php $_POST[$_SERVER]?>" method="post">
<table>



<tr align="center">
<td colspan="7">Facture</td>
</tr>

<tr align="center">
<td><label for="articleID">Article </label></td>
<td><label for="price">O Price</label></td>
<td><label for="price1">D price</label></td>
<td><label for="Difference">Difference</label></td>
<td><label for="size">Size:</label></td>
<td><label for="quantity">Qty:</label></td>
<td><label for="Cash">Cash:</label></td>
</tr>

<tr>
<td><input name="articleID" id="articleID" size="5" maxlength="7"></td>
<td><input name="price" id="price" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1" id="price1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff1" id="diff1" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="size" id="size" size="5" maxlength="3" onChange="app()"></td>
<td><input name="quantity" id="quantity" size="5" maxlength="3"></td>
<td><input name="Cash" id="Cash" size="20" maxlength="255" class="tot"></td>
</tr>

<tr>
<td><input name="articleIDa" id="articleIDa" size="5" maxlength="7"></td>
<td><input name="pricea" id="pricea" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1a" id="price1a" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff2" id="diff2" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizea" id="sizea" size="5" maxlength="3" onClick="app()" onChange="update()" ></td>
<td><input name="quantitya" id="quantitya" size="5" maxlength="3"></td>
<td><input name="Casha" id="Casha" size="20" maxlength="255" class="tot"></td>
</tr>

<tr>
<td><input name="articleIDb" id="articleIDb" size="5" maxlength="7"></td>
<td><input name="priceb" id="priceb" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1b" id="price1b" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff3" id="diff3" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizeb" id="sizeb" size="5" maxlength="3" onClick="app()"></td>
<td><input name="quantityb" id="quantityb" size="5" maxlength="3"></td>
<td><input name="Cashb" id="Cashb" size="20" maxlength="255" class="tot"></td>
</tr>

<tr>
<td><input name="articleIDc" id="articleIDc" size="5" maxlength="7"></td>
<td><input name="pricec" id="pricec" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1c" id="price1c" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff4" id="diff4" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizec" id="sizec" size="5" maxlength="3"></td>
<td><input name="quantityc" id="quantityc" size="5" maxlength="3"></td>
<td><input name="Cashc" id="Cashc" size="20" maxlength="255" class="tot"></td>
</tr>

<tr>
<td><input name="articleIDd" id="articleIDd" size="5" maxlength="7"></td>
<td><input name="priced" id="priced" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1d" id="price1d" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff5" id="diff5" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sized" id="sized" size="5" maxlength="3"></td>
<td><input name="quantityd" id="quantityd" size="5" maxlength="3"></td>
<td><input name="Cashd" id="Cashd" size="20" maxlength="255" class="tot"></td>
</tr>

<tr>
<td><input name="articleIDe" id="articleIDe" size="5" maxlength="7"></td>
<td><input name="pricee" id="pricee" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="price1e" id="price1e" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="diff6" id="diff6" size="10" maxlength="255" readonly="readonly"></td>
<td><input name="sizee" id="sizec" size="5" maxlength="3"></td>
<td><input name="quantitye" id="quantitye" size="5" maxlength="3"></td>
<td><input name="Cashe" id="Cashe" size="20" maxlength="255" class="tot"></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td align="right">Total :</td>
<td align="center"><span id="sum">0</span></td>

</tr>
<tr>


</tr>
</table>
<input type="submit" name="submit" id="submit" value="submit">
<input type="reset" name="reset" id="reset" value="reset">
</form>


<div id="images"></div>
<!-- Begin 1st line  -->
<!--  from 1st article to 1st size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleID, #size').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 1st size to the 2nd article  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#size, #articleIDa').autotab_magic().autotab_filter('numeric');
});
</script>

<!--when we click on the 1st article -->
<script type="text/javascript">
$("#articleID").bind("change", function(e){
$.getJSON("getarticle2.php?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<!--when we change the 1st article we need to check if it exist or not-->
<script type="text/javascript">
$("#articleID").bind("change", function(e){
$.getJSON("checkarticle2.php?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 1st line   price1 -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getmultipleprice.php?qty=" + $("#quantity").val() +"&p=" + $("#price1").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1a") {
$("#price1").val(item.value);
} else if (item.field == "diff1") {
$("#diff1").val(item.value);
} else if (item.field == "Cash") {
$("#Cash").val(item.value);
} else if (item.field == "quantity") {
$("#quantity").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 1st Line -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getsum.php?qty=" + $("#quantity").val() + "&?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "total") {
$("#total").val(item.value);
}
});
});
});
</script>
<!--End 1st Line -->
<!-- Begin 2nd line  -->

<!--  from 2nd article to 2nd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDa, #sizea').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 2nd size to the 3nd article  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#sizea, #articleIDb').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDa").bind("change", function(e){
$.getJSON("getarticlea.php?aID=" + $("#articleIDa").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricea") {
$("#pricea").val(item.value);
} else if (item.field == "price1a") {
$("#price1a").val(item.value);
} else if (item.field == "diff2") {
$("#diff2").val(item.value);
} else if (item.field == "Casha") {
$("#Casha").val(item.value);
} else if (item.field == "quantitya") {
$("#quantitya").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 2nd line with the price1a -->
<script>
$("#quantitya").bind("change", function(e){
$.getJSON("getmultiplepricea.php?qty=" + $("#quantitya").val() +"&p=" + $("#price1a").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Casha") {
$("#Casha").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 1st Line -->
<script>
$("#quantity").bind("change", function(e){
$.getJSON("getsuma.php?qty=" + $("#quantitya").val() + "&?aID=" + $("#articleIDa").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Casha") {
$("#Casha").val(item.value);
}
});
});
});
</script>
<!-- End of 2nd Line -->

<!-- Begin 3rd Line -->

<!--  from 3rd article to 3rd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDb, #sizeb').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 3rd size to the 4th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sizeb, #articleIDc').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDb").bind("change", function(e){
$.getJSON("getarticleb.php?aID=" + $("#articleIDb").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "priceb") {
$("#priceb").val(item.value);
} else if (item.field == "price1b") {
$("#price1b").val(item.value);
} else if (item.field == "diff3") {
$("#diff3").val(item.value);
} else if (item.field == "Cashb") {
$("#Cashb").val(item.value);
} else if (item.field == "quantityb") {
$("#quantityb").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 3rd line with the price1b -->
<script>
$("#quantityb").bind("change", function(e){
$.getJSON("getmultiplepriceb.php?qty=" + $("#quantityb").val() +"&p=" + $("#price1b").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashb") {
$("#Cashb").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 3rd Line -->
<script>
$("#quantityb").bind("change", function(e){
$.getJSON("getsumb.php?qty=" + $("#quantityb").val() + "&?aID=" + $("#articleIDb").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashb") {
$("#Cashb").val(item.value);
}
});
});
});
</script>

<!-- End 3rd Line -->
<!-- Begin of 4th line -->
<!--  from 3rd article to 3rd size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDc, #sizec').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 3rd size to the 4th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sizec, #articleIDd').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDc").bind("change", function(e){
$.getJSON("getarticlec.php?aID=" + $("#articleIDc").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricec") {
$("#pricec").val(item.value);
} else if (item.field == "price1c") {
$("#price1c").val(item.value);
} else if (item.field == "diff4") {
$("#diff4").val(item.value);
} else if (item.field == "Cashc") {
$("#Cashc").val(item.value);
} else if (item.field == "quantityc") {
$("#quantityc").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 4th line with the price1b -->
<script>
$("#quantityc").bind("change", function(e){
$.getJSON("getmultiplepricec.php?qty=" + $("#quantityc").val() +"&p=" + $("#price1c").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashc") {
$("#Cashc").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 4th Line -->
<script>
$("#quantityc").bind("change", function(e){
$.getJSON("getsumc.php?qty=" + $("#quantityc").val() + "&?aID=" + $("#articleIDc").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashc") {
$("#Cashc").val(item.value);
}
});
});
});
</script>
<!-- End of the 4th line -->

<!-- Begin of 5th line -->
<!--  from 5th article to 5th size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDd, #sized').autotab_magic().autotab_filter('numeric');
});
</script>

<!--  from 5rd size to the 6th article  -->
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('#sized, #articleIDe').autotab_magic().autotab_filter('numeric');
});
</script>
<script>
$("#articleIDd").bind("change", function(e){
$.getJSON("getarticled.php?aID=" + $("#articleIDd").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "priced") {
$("#priced").val(item.value);
} else if (item.field == "price1d") {
$("#price1d").val(item.value);
} else if (item.field == "diff5") {
$("#diff5").val(item.value);
} else if (item.field == "Cashd") {
$("#Cashd").val(item.value);
} else if (item.field == "quantityd") {
$("#quantityd").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 5th line with the price1b -->
<script>
$("#quantityd").bind("change", function(e){
$.getJSON("getmultiplepriced.php?qty=" + $("#quantityd").val() +"&p=" + $("#price1d").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashd") {
$("#Cashd").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 5th Line -->
<script>
$("#quantityd").bind("change", function(e){
$.getJSON("getsumd.php?qty=" + $("#quantityd").val() + "&?aID=" + $("#articleIDd").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashd") {
$("#Cashd").val(item.value);
}
});
});
});
</script>
<!-- End of the 5th line -->

<!-- Begin of 6th line 
<!--  from 6th article to 6th size  -->
<script type="text/javascript">
$(document).ready(function() {
    $('#articleIDe, #sizee').autotab_magic().autotab_filter('numeric');
});
</script>

<script>
$("#articleIDe").bind("change", function(e){
$.getJSON("getarticlee.php?aID=" + $("#articleIDe").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "pricee") {
$("#pricee").val(item.value);
} else if (item.field == "price1e") {
$("#price1e").val(item.value);
} else if (item.field == "diff6") {
$("#diff6").val(item.value);
} else if (item.field == "Cashe") {
$("#Cashe").val(item.value);
} else if (item.field == "quantitye") {
$("#quantitye").val(item.value);
}
});
});
});
</script>

<!--   to get the multiple for the 6th line with the price1e -->
<script>
$("#quantitye").bind("change", function(e){
$.getJSON("getmultiplepricee.php?qty=" + $("#quantitye").val() +"&p=" + $("#price1e").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashe") {
$("#Cashe").val(item.value);
}
});
});
});
</script>

<!-- when we change the quantity of the 6th Line -->
<script>
$("#quantitye").bind("change", function(e){
$.getJSON("getsume.php?qty=" + $("#quantitye").val() + "&?aID=" + $("#articleIDe").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "Cashe") {
$("#Cashe").val(item.value);
}
});
});
});
</script> 
<!-- End of the 6th line -->

<script>
// that script calculate the sum of all cash to be paid by the customer.
//First we get all the text boxs that have the class="tot" 
// After that we use the function calculateSum()
    $(document).ready(function(){
 
        //iterate through each textboxes and add keyup
        //handler to trigger sum event
        $(".tot").each(function() {
 
            $(this).keyup(function(){
                calculateSum();
            });
        });
 
    });
 
 // calculateSum function
    function calculateSum() {
 
        var sum = 0;
        //iterate through each textboxes and add the values
        $(".tot").each(function() {
 
            //add only if the value is number
            if(!isNaN(this.value)&&this.value.length!=0) {
                sum += parseFloat(this.value);
            }
 
        });
        //.toFixed() method will roundoff the final sum to 2 decimal places
        $("#sum").html(sum.toFixed(2));
    }
</script>

</center>
</BODY>
</HTML>