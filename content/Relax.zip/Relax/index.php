<?php ob_start(); ?>
<html>
 <title>Login</title>
<head>

<style type="text/css">
<!--
.style1 {color: #000000}
.helpHed tr td #DivExample font {
	font-size: x-small;
}
-->
</style>
 <link href="lib/styles.css" rel="stylesheet" type="text/css" />
 <link href="lib/table_style.css" rel="stylesheet" type="text/css" />

</head>
<body background="images/bg_index.jpg">

<form name="loginform" action="login_direction.php" method="post">
<br /><br /><br /><br />
  <table boder=0 cellpadding="0" cellspacing="0" width="350" align="center" class="helpHed" bgcolor="#99FFFF">
    <tr>
      <td colspan="3" width="350"><table boder=0 cellpadding="0" cellspacing="0" width="350" align="center">
        <tr>
          <td align="center"  width="11" height="21" class="formstyle" >&nbsp;</td>
          <td align="center" height="21" class="formstyle" background="../images/3gb.jpg">&nbsp;</td>
          <td align="center" height="21"  width="12" class="formstyle">&nbsp;</td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td colspan=3 align="center" height="25" valign="top" class="helpHed">Please Enter your Username and Password</td>
    </tr>
   <tr><td></td><td>
<?php 
session_start();
if(isset($_SESSION['invalid_pass1'])){ ?> 
     <div id=DivExample  frameborder=0 width=80 height=80><font color="red" face="Times New Roman, Times, serif" >invalid user name or password</font> </div> <?php  
	 unset($_SESSION['invalid_pass1']);
	 }?>
</td></tr>
    <tr>
      <td width="108"  height="25" align="right" class="helpHed">User Name:&nbsp;</td>
      <td width="178"><input name="usertxt" type="text" id="usertxt" style="width:175px" /></td>
      <td width="65" class="helpHed">&nbsp;</td>
    </tr>
    <tr>
      <td align="right" height="25" class="helpHed" >Password:&nbsp;</td>
      <td><input name="passtxt" type="password" id="passtxt" style="width:175px" /></td>
      <td width="65" class="helpHed">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
     
    </tr>
    <tr>
    <td></td> 
    <td align="center" class="helpHed">
      <label>
        <select name="signin_type" id="signin_type" align="center">
          <option value="employee" selected="selected">Employee</option>
          <option value="admin">Admin</option>
          <option value="super_admin">Super Admin</option>
        </select>
      </label>
    </td>
    <td >&nbsp;</td>
    </tr>
    <tr>
      <td colspan=3 align="center">&nbsp;</td>
    </tr>
    <tr>
      <td align="center">&nbsp;</td>
      <td align="center" ><input type="submit" name="login" style="width:55px;" value="Login" class="butonstyle" /></td>
      <td align="center">&nbsp;</td>
    </tr>
    <tr>
      <td colspan=3 align="center" height="25">&nbsp;</td>
    </tr>
  </table>
</form>

<center><img src="images/logo.jpg" border="0"></center>
</body>
</html>