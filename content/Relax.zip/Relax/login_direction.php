<?php
$position=$_POST['signin_type'];


if($position ==  "employee"){
	
	require_once("employee/login.php");
	
}
   
   
   
   
   
elseif($position ==  "admin"){
	
	require_once("admin/login.php");
	
}
		  
	
	
	
	
	
		  
elseif($position ==  "super_admin"){
	
	require_once("super_admin/login.php");
}


?>