<?php session_start() ?>
<?php
ob_start();
require_once("../config/connect.php");

$articleid=$_POST['articletxt'];
$arcticle_purch_price=$_POST['purchasetxt'];
$article_sale_price=$_POST['salepricetxt'];
$after_solde_price=$_POST['aftersalepricetxt'];
$supp_name=$_POST['article_supp_name'];

// Check to see if the article is already inserted or not!
$result=mysql_query($Checkifexist="SELECT COUNT(*) as nb FROM `article` WHERE `article_id`='$articleid'");
while($res=mysql_fetch_array($result)){
	if($res['nb']=1){
		?>
		<script language="javascript">
	//alert("You already create this article ");
	location = 'insert_article.php';
	</script>
    <?php
	exit;
		}
		

}

$Getsupid=mysql_query("SELECT * 
FROM  `supplier`
WHERE  `supplier_name` LIKE CONVERT( _utf8 '$supp_name'
USING latin1 ) 
COLLATE latin1_swedish_ci
LIMIT 0 , 30");
while($result=mysql_fetch_array($Getsupid)){
	$sup_id=$result['supplier_id'];

}
//echo $articleid;echo "<br>";echo $arcticle_purch_price;echo "<br>";echo $article_sale_price;echo "<br>";echo $after_solde_price;echo "<br>";

//Insert the new article into the database!
$Insertintoarticle="INSERT INTO  `article` (  `article_id` ,  `article_pur_price` ,  `article_sale_price` ,  `article_after_solde_price` ,  `article_supplier_id` ) VALUES ('$articleid', '$arcticle_purch_price' , '$article_sale_price' , '$after_solde_price' , '$sup_id');";
echo $query2;
@mysql_query($Insertintoarticle);

//header('Location:insert_article.php');

?>