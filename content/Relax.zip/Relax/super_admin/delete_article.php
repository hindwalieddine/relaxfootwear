<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include("include/menu.php");
$id=$_GET['id'];
$DeleteArticle="DELETE FROM `article` WHERE `article`.`article_id`=$id LIMIT 1";
//echo $DeleteArticle;
@mysql_query($DeleteArticle);
?>
		<script language="javascript">
	alert('Article Deleted Successfully');
	location = 'insert_article.php';
	</script>
	<?php 
	exit;
	?>