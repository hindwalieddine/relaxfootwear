<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include("include/menu.php");
$id=$_GET['id'];
$DeleteSupplier="DELETE FROM `supplier` WHERE `supplier`.`supplier_id`=$id LIMIT 1";
//echo $DeleteArticle;
@mysql_query($DeleteSupplier);
?>
		<script language="javascript">
	alert('Article Deleted Successfully');
	location = 'insert_supplier.php';
	</script>
	<?php 
	exit;
	?>