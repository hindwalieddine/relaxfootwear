<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include("include/menu.php");
$id=$_GET['id'];
if(isset($_POST['submit'])){
//$id=$_GET['id'];
	$newid=$_POST['newid'];
	$newpurchprice=$_POST['newpurchprice'];
	$newsaleprice=$_POST['newsaleprice'];
	$newaftersaleprice=$_POST['newaftersaleprice'];
    $supp_name=$_POST['article_supp_name'];
	
	//get the supplier id
	$GetSuppid=mysql_query("SELECT * FROM supplier WHERE  `supplier_name` =  \"$supp_name\" LIMIT 0 , 30");
	while($total=mysql_fetch_array($GetSuppid)){
		$newsuppid=$total['supplier_id'];
	}
	
$UpdateArticle_Query = "UPDATE  `article` SET  `article_id` =  '$newid',`article_pur_price` =  '$newpurchprice',`article_sale_price` =  '$newsaleprice',`article_after_solde_price` =  '$newaftersaleprice',`article_supplier_id` =  '$newsuppid',`article_image` =  '0000' WHERE  `article`.`article_id` =$id LIMIT 1 ;";
// echo $UpdateArticle_Query;
 @mysql_query($UpdateArticle_Query);
 ?>
		<script language="javascript">
	alert('Article Edited Successfully');
	location = 'insert_article.php';
	</script>
	<?php 
	exit;

}
?>
<form name="updatearticleform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table align="center" border="0">
        <tr>
          <th colspan="2">Update Article</th>
        </tr>
        <?php
		$ReadArticles=mysql_query("SELECT * 
                                   FROM  `article`
                                   WHERE  `article_id` =$id
                                   LIMIT 0 , 30");
while($oldresult=mysql_fetch_array($ReadArticles)){
	$oldid=$oldresult['article_id'];
	$oldpurchprice=$oldresult['article_pur_price'];
	$oldsaleprice=$oldresult['article_sale_price'];
	$oldaftersoldprice=$oldresult['article_after_solde_price'];
	
}
	?>
        <tr>
          <td>Article number: *</td>
          <td><input type="text" name="newid" id="newid" value="<?php echo $oldid; ?>"/></td>
        </tr>
        <tr>
          <td>Purchase price:*</td>
          <td><input type="text" name="newpurchprice" id="newpurchprice" value="<?php echo $oldpurchprice; ?>"/></td>
        </tr>
        <tr>
          <td>Sale price:*</td>
          <td><input type="text" name="newsaleprice" id="newsaleprice" value="<?php echo $oldsaleprice; ?>" /></td>
        </tr>
        <tr>
          <td>After solde price:</td>
          <td><input type="text" name="newaftersaleprice" id="newaftersaleprice" value="<?php echo $oldaftersoldprice; ?>"/></td>
        </tr>
        <?php
	$result=mysql_query("SELECT * FROM `supplier` ORDER BY supplier_name");
	//echo $query; echo "<br>";
    ?>
        <tr>
          <td>Supplier:*</td>
          <td><select name="article_supp_name">
              <?php
	while($getSupplier=mysql_fetch_array($result)){
	echo $getSupplier['supplier_name'];
		?>
              <option value="<?php echo $getSupplier['supplier_name'];?>"> <?php echo $getSupplier['supplier_name'];?> </option>
              <?php
    }
	?>
            </select>
          <td>
        </tr>
        
        <tr><td colspan="2">Insert a picture:</td></tr>
        <tr><td colspan="2"><input type="file" name="article_image" /></td>
        <tr>
          <td align="center" colspan="2"><input type="submit" name="submit" value="Update"></td>
        </tr>
      </table>