<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include("include/menu.php");
if(isset($_POST['submit'])){
$id=$_GET['id'];
$suppname=$_POST['suppnametxt'];
$suppphone=$_POST['phonetxt'];
$suppmobile=$_POST['mobiletxt'];
$suppaddress=$_POST['Addresstext'];
$suppnotes=$_POST['Notetext'];
	
	
$UpdateSupplier_Query = "UPDATE  `supplier` SET  `supplier_name` =  '$suppname',`supplier_phone` =  '$suppphone',`supplier_mobile` =  '$suppmobile',`supplier_address` =  '$suppaddress',`supplier_notes` =  '$suppnotes' WHERE  `supplier`.`supplier_id` =$id LIMIT 1 ;";
 echo $UpdateArticle_Query;
 @mysql_query($UpdateSupplier_Query);
 ?>
		<script language="javascript">
	alert('Supplier Edited Successfully');
	location = 'insert_supplier.php';
	</script>
	<?php 
	exit;

}
?>
<form name="updatearticleform" action="<?php $_SERVER['PHP_SELF']?>" method="post">
  <table align="center">
        <tr>
          <th colspan="2">Update Supplier</th>
        </tr>
        <tr>
          <td>Supplier Name: *</td>
          <td><input type="text" name="suppnametxt" id="suppnametxt"/></td>
        </tr>
        <tr>
          <td>Phone:</td>
          <td><input type="text" name="phonetxt" id="phonetxt"/></td>
        </tr>
        <tr>
          <td>Mobile:</td>
          <td><input type="text" name="mobiletxt" id="mobiletxt" /></td>
        </tr>
        <tr>
          <td>Address:</td>
          <td><input type="text" name="Addresstext" id="Addresstext"/></td>
        </tr>
                <tr>
          <td>Notes:</td>
          <td><input type="text" name="Notetext" id="Notetext"/></td>
        </tr>
        <tr>
          <td align="center" colspan="2"><input type="submit" name="submit" value="Update"></td>
        </tr>
      </table>