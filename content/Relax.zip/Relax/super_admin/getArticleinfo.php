<?php
ob_start();
include_once("include/menu.php");
include_once("../config/connect.php");
?>
<HTML>
<HEAD>
<style type="text/css">
body{
background-repeat:no-repeat;
font-family: Trebuchet MS, Lucida Sans Unicode, Arial, sans-serif;
height:100%;
background-color: #FFF;
margin:0px;
padding:0px;
background-image:url('/images/heading3.gif');
background-repeat:no-repeat;
padding-top:85px;
}

fieldset{
width:500px;
margin-left:10px;
}

</style>
<!-- script type="text/javascript" src="jquery-1.5.1.min.js"></script -->
<script type="text/javascript" src="js/jquery-latest.min.js"></script>
<!-- Auto Tab -->
<script type="text/javascript" src="js/jquery.autotab.js"></script>
<SCRIPT LANGUAGE="javascript">

<!-- This code makes the jump from textbox one to textbox two -->
function checkArticle()
{
var letters = document.articleForm.articleID.value.length +1;
if (letters <= 7 )
{document.articleForm.articleID.focus()}
else
{document.articleForm.price.focus()}
}
</script>
</HEAD>
<BODY onLoad="document.articleForm.articleID.focus()">
<center>
<form name="articleForm" method="post">
<fieldset>
<legend>article information</legend>
<table>
<tr>
<td><label for="articleID">article ID:</label></td>
<td><input name="articleID" id="articleID" size="5" maxlength="7" onKeyUp="checkArticle()"></td>
</tr>
<tr>
<td><label for="price">purchase Price:</label></td>
<td><input name="price" id="price" size="20" maxlength="255" readonly="readonly"></td>
</tr>
<tr>
<td><label for="price1">1st Price:</label></td>
<td><input name="price1" id="price1" size="20" maxlength="255" readonly="readonly"></td>
</tr>
<tr>
<td><label for="price2">2nd Price:</label></td>
<td><input name="price2" id="price2" size="20" maxlength="255" readonly="readonly"></td>
</tr>
<tr>
  <td><label for="supplier">Supplier:</label></td>
  
  <td>
    <SELECT name="supplier" id="supplier">
  <option value="">--</option>

  <?php
  $ReadSupplier=mysql_query("SELECT * FROM  `supplier` ORDER BY  `supplier`.`supplier_name` ASC LIMIT 0 , 30 ");
while($GetAllSuppliers=mysql_fetch_array($ReadSupplier)){
?>

 <option value="<?php echo $GetAllSuppliers['supplier_name'] ?>"> <?php echo $GetAllSuppliers['supplier_name']; ?></option>

  <?php  } ?>
  </SELECT>
  </td>
</tr>
<tr>
<td><input type="reset" id="reset" value="reset"></td>
</tr>
</table>
</fieldset>
</form>


<div id="images"></div>

<script type="text/javascript">
$("#articleID").bind("change", function(e){
$.getJSON("getarticle2.php?aID=" + $("#articleID").val(),
function(data){
$.each(data, function(i,item){
if (item.field == "price") {
$("#price").val(item.value);
} else if (item.field == "price1") {
$("#price1").val(item.value);
} else if (item.field == "price2") {
$("#price2").val(item.value);
} else if (item.field == "supplier") {
$("#supplier").val(item.value);
} 
});
});
});
</script>
</center>

</BODY>
</HTML>