<?php
include_once("../config/connect.php");

$id=$_GET['aID'];

if (isset($id)) {
$result=mysql_query("SELECT * FROM article WHERE article_id='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {
	$supid=$plist[article_supplier_id];
	$suppresult=mysql_query("SELECT * FROM supplier WHERE supplier_id='$supid'") or die("error: ".mysql_error());
	if($plist1=mysql_fetch_assoc($suppresult)) {
	$suppname=$plist1[supplier_name];}

$json = array(array('field' => 'price',
'value' => $plist[article_pur_price]),
array('field' => 'price1',
'value' => $plist[article_sale_price]),
array('field' => 'price2',
'value' => $plist[article_after_solde_price]),
array('field' => 'supplier',
'value' => $suppname) //last item should have no comma
);
}
}
print json_encode($json);
?>