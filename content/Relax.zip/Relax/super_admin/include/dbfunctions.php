<?php
require_once("../config/connect.php");
//Get the id number of the supplier.
public function Get_id_of_supplier($supplier_name){
$Getsupid=mysql_query("SELECT * 
FROM  `supplier`
WHERE  `supplier_name` LIKE CONVERT( _utf8 '$supplier_name'
USING latin1 ) 
COLLATE latin1_swedish_ci
LIMIT 0 , 30");
while($result=mysql_fetch_array($Getsupid)){
	$sup_id=$result['supplier_id'];

}
$Insertintoarticle="INSERT INTO  `article` (  `article_id` ,  `article_pur_price` ,  `article_sale_price` ,  `article_after_solde_price` ,  `article_supplier_id` ) VALUES ('$articleid', '$arcticle_purch_price' , '$article_sale_price' , '$after_solde_price' , '$sup_id');";
echo $query2;
@mysql_query($Insertintoarticle);

}
}
?>