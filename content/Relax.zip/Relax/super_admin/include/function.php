<?php

function login_user_pass_defined($user_right,$pass_right){
	session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{

	$user = $_POST[usertxt];
	$pass = $_POST[passtxt];
	

	if ($user == $user_right && $pass == $pass_right)
	{ 
	
		$_SESSION['check_login_superadmin']   =  "already_login_superadmin" ;
		
		?> <script type="text/javascript"> window.location="super_admin/home.php"; </script> <?php
		exit();
	}
	
  

//if pass invalid
else
  { 
  
    $_SESSION['invalid_pass1']="invalid_pass1";
	 ?> <script type="text/javascript"> window.location="index.php"; </script> <?php
	exit();
	 }
    
   
}
}//function






function check_login_superadmin()
{
	
if($_SESSION['check_login_superadmin'] != 'already_login_superadmin')
{
$LoginLink = "<a href=\"../index.php\">Login</a>";
echo "your time is out click here to $LoginLink";
exit();
}
else{};
}//function

?>