<html>
<table width="826" align="center" bgcolor="#3399FF">
<tr><td width="87" height="30"><a href="home.php">Home</a></td>
<td width="104"><a href="insert_article.php">Add Article</a></td>
<td width="165"><a href="getArticleinfo.php">See information on an article</a></td>
<td width="132"><a href="insert_supplier.php">Add Supplier</a></td>
<td width="144"><a href="insert_customer.php">Add Customer</a></td>
<td width="146"><a href="edit_bills.php">Edit Bills</a></td>
<td width="91"><a href="logout.php">Logout</a></td>

</tr>
</table>
</html>