<?php
//upload the file

if($_FILES['file']['name'] && $_FILES['file']['size'] > 0 ) //if admin browse a new file
{
	$image=mysql_real_escape_string($_POST['article_image']);
	
	$FileName = $_FILES['file']['image']; //filename on the client side
	$TmpName  = $_FILES['file']['tmp_name']; //temporary filename on server
	$FileSize = $_FILES['file']['size']; //filesize
	$FileType = $_FILES['file']['type']; //type
	
$now = time();
	while(file_exists( $FileName= $now.'-'.$FileName))
	{
		$now++;
	}

	$UploadDir ='./uploads/';
	$FilePath = $UploadDir."$FileName";
	echo $FilePath;echo "<br>";
	move_uploaded_file($_FILES["file"]["tmp_name"],$FilePath);
	
	
}//if


?>
