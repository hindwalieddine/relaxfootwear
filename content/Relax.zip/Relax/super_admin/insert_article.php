<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include_once("include/menu.php");
if(isset($_POST['submit'])){
$articleid=$_POST['articletxt'];
$arcticle_purch_price=$_POST['purchasetxt'];
$article_sale_price=$_POST['salepricetxt'];
$after_solde_price=$_POST['aftersalepricetxt'];
$supp_name=$_POST['article_supp_name'];
$article_img=$_POST['article_image'];
//echo "img: ".$article_img; echo "<br>";


if(($articleid==NULL)||($arcticle_purch_price==NULL)||($article_sale_price==NULL)||($supp_name==NULL)){
	?>
	<script language="javascript">
	alert("You must fill all the required field ");
	location = 'insert_article.php';
	</script>
    	<script language="javascript">

    <?php
	exit;

}

		if($articleid.length!=7){ ?>
	<!--script>
	//alert("You need to insert a 7 digit article ");
	//location = 'insert_article.php';
	</script>-->
    <?php
	
    }
// Check to see if the article is already inserted or not!

	$count=mysql_query("SELECT COUNT( * ) AS nb
FROM  `article` 
WHERE  `article`.`article_id` =  '$articleid' LIMIT 1;");
$result=mysql_fetch_array($count);
$nb=$result['nb'];
//echo "nb: ".$nb; echo "<br>";
if($nb==1){?>
	<script language="javascript">
	alert("You have already created this article");
	location = 'insert_article.php';
	</script>
    <?php
	exit;
}


$Getsupid=mysql_query("SELECT * 
FROM  `supplier`
WHERE  `supplier_name` LIKE CONVERT( _utf8 '$supp_name'
USING latin1 ) 
COLLATE latin1_swedish_ci
LIMIT 0 , 30");
while($result=mysql_fetch_array($Getsupid)){
	$sup_id=$result['supplier_id'];

}
//echo $articleid;echo "<br>";echo $arcticle_purch_price;echo "<br>";echo $article_sale_price;echo "<br>";echo $after_solde_price;echo "<br>";

include("include/uploadimage.php");


//Insert the new article into the database!
$Insertintoarticle="INSERT INTO  `article` (  `article_id` ,  `article_pur_price` ,  `article_sale_price` ,  `article_after_solde_price` ,  `article_supplier_id` ,`article_image`) VALUES ('$articleid', '$arcticle_purch_price' , '$article_sale_price' , '$after_solde_price' , '$sup_id',\"$article_img\")";
//echo $Insertintoarticle;
@mysql_query($Insertintoarticle);

//header('Location:insert_article.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<script type="text/javascript" src="fckeditor/fckeditor.js"></script>
<!-- Auto Tab -->
<script type="text/javascript" src="js/jquery.autotab.js"></script>
<SCRIPT LANGUAGE="javascript">

<!-- This code makes the jump from textbox one to textbox two -->
function checkArticle()
{
var letters = document.menu1.articletxt.value.length +1;
if (letters <= 7 )
{document.menu1.articletxt.focus()}
else
{document.menu1.purchasetxt.focus()}
}
</script>
<script>
function check(){
var lenarticle = document.menu1.articletxt.value.length;
if(lenarticle!=7){ document.write(aaaa);}	
}
</script>
</head>
<body onLoad="document.menu1.articletxt.focus()">
<form name="menu1" action="<?php $_SERVER[PHP_SELF]?>" enctype="multipart/form-data" method="post">
  <table width="1000" align="center" border="0">
  <tr>
    <td width="200" valign="top"><table align="center">
        <tr>
          <th colspan="2">Insert new Article</th>
        </tr>
        <tr>
          <td>Article number: *</td>
          <td><input type="text" name="articletxt" id="articletxt" maxlength="7" onKeyUp="checkArticle()"/></td>
        </tr>
        <tr>
          <td>Purchase price:*</td>
          <td><input type="text" name="purchasetxt" id="purchasetxt"/></td>
        </tr>
        <tr>
          <td>Sale price:*</td>
          <td><input type="text" name="salepricetxt" id="salepricetxt" /></td>
        </tr>
        <tr>
          <td>After solde price:</td>
          <td><input type="text" name="aftersalepricetxt" id="aftersalepricetxt"/></td>
        </tr>
        <?php
	$result=mysql_query("SELECT * FROM `supplier` ORDER BY supplier_name");
	//echo $query; echo "<br>";
    ?>
        <tr>
          <td>Supplier:*</td>
          <td><select name="article_supp_name">
              <?php
	while($getSupplier=mysql_fetch_array($result)){
	echo $getSupplier['supplier_name'];
		?>
              <option value="<?php echo $getSupplier['supplier_name'];?>"> <?php echo $getSupplier['supplier_name'];?> </option>
              <?php
    }
	?>
            </select>
          <td>
        </tr>
        
        <tr><td colspan="2">Insert a picture:</td></tr>
        <tr><td colspan="2"><input type="file" name="article_image" id="article_image"/></td></tr>
        <tr>
          <td align="center" colspan="2"><input type="submit" name="submit" value="Save" onClick="check()"></td>
        </tr>
      </table border="1"></td>
    <td><table width="700" align="center" border="1" style="border-spacing:0; border:thin" bordercolorlight="#666666">
      <tr>
        <td align="center" colspan="7"> All Articles</td>
      </tr>
      <tr>
        <td width="78" height="20">Article</td>
        <td width="76" height="20">P. Price</td>
        <td width="76" height="20">Or. Price</td>
        <td width="76" height="20">  Price</td>
        <td width="300" height="20">Supplier Name</td>
        <td width="13" height="20"></td>
        <td width="13" height="20"></td>
      </tr>
      <?php
	  //Pour les pagination du page
	  $messagesParPage=40; //Nous allons afficher 5 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM article "); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire

// La requête sql pour récupérer les messages de la page actuelle.
$GetAllArticles=mysql_query(" SELECT * 
FROM  `article` 
ORDER BY  `article`.`article_id` ASC 
LIMIT ".$premiereEntree.", ".$messagesParPage." ");


	//	$description = substr($donnees_messages[news_desc],0,300)."...";
     //Je vais afficher les messages dans des petits tableaux. C'est à vous d'adapter pour votre design...
     //De plus j'ajoute aussi un nl2br pour prendre en compte les sauts à la ligne dans le message.     

	while($GetArticles=mysql_fetch_array($GetAllArticles)){
		$suppid=$GetArticles['article_supplier_id'];
		//get the name of the supplier from the id
		$suppresult=mysql_query("SELECT * FROM supplier WHERE supplier_id='$suppid'") or die("error: ".mysql_error());
	if($plist1=mysql_fetch_assoc($suppresult)) {
	$suppname=$plist1[supplier_name];}
		
		echo "<tr>";
		echo "<td width=\"78\" height=\"20\">".$GetArticles['article_id']."</td>";
		echo "<td width=\"76\" height=\"20\">".$GetArticles['article_pur_price']."</td>";
		echo "<td width=\"76\" height=\"20\">".$GetArticles['article_sale_price']."</td>";
		echo "<td width=\"76\" height=\"20\">".$GetArticles['article_after_solde_price']."</td>";
		echo "<td width=\"300\" height=\"20\">".$suppname."</td>";
		echo "<td width=\"13\" height=\"20\">";
		?>
        <a href="edit_article.php?id=<?php echo $GetArticles[article_id];?>"><img width="20" height="20" src="images/edit.jpg"  /></a>
        <td width="13" height="28"><a href="delete_article.php?id=<?php echo $GetArticles[article_id];?>"><img width="20" height="20" src="images/b_drop.png"  /></a> </td>
  
        <?php
		echo "</tr>";
	} // End while
?>
    </table>
      <?php
//pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="insert_article.php?page='.$i.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
?>
    
    
    
    </td>
      </tr></table>
</form>
<script language="JavaScript" type="text/javascript">
var frmvalidator = new Validator("menu1");
frmvalidator.addValidation("articletxt","req","Please enter an article");
frmvalidator.addValidation("purchasetxt","req","Please enter the purchase price");
frmvalidator.addValidation("salepricetxt","req","Please enter a Sale price");
frmvalidator.addValidation("article_supp_name","req","Please choose a supplier")
</script>
</body>
</html>