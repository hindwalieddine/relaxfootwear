<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include_once("include/menu.php");
if(isset($_POST['submit'])){
$suppname=$_POST['suppnametxt'];
$suppphone=$_POST['phonetxt'];
$suppmobile=$_POST['mobiletxt'];
$suppaddress=$_POST['Addresstext'];
$suppnotes=$_POST['Notetext'];
if($suppname==NULL){?>
	<script language="javascript">
	alert("You must fill the supplier name ");
	location = 'insert_supplier.php';
	</script>
    <?php
	exit;

} // end if
    
//Insert the new supplier into the database!
$Insertintosupplier="INSERT INTO  `supplier` (  `supplier_id` ,  `supplier_name` ,  `supplier_phone` ,  `supplier_mobile` ,  `supplier_address` ,`supplier_notes`) VALUES ('', '$suppname' , '$suppphone' , '$suppmobile' , '$suppaddress','$suppnotes')";
//echo $Insertintosupplier;
@mysql_query($Insertintosupplier);
		?>
		<script language="javascript">
	//alert("SuppLIER CREATED ");
	location = 'insert_supplier.php';
	</script>
    <?php
	exit;

} //end while

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="fckeditor/fckeditor.js"></script>
<!-- Auto Tab -->
<script type="text/javascript" src="js/jquery.autotab.js"></script>
<SCRIPT LANGUAGE="javascript">

<!-- This code makes the jump from textbox one to textbox two -->
function checkphone()
{
var letters = document.suppmenu.phonetxt.value.length +1;
if (letters <= 8 )
{document.suppmenu.phonetxt.focus()}
else
{document.suppmenu.mobiletxt.focus()}
}
</script>
<SCRIPT LANGUAGE="javascript">

<!-- This code makes the jump from textbox one to textbox two -->
function checkmobile()
{
var letters = document.suppmenu.mobiletxt.value.length +1;
if (letters <= 8 )
{document.suppmenu.mobiletxt.focus()}
else
{document.suppmenu.Addresstext.focus()}
}
</script>
<body onload="document.suppmenu.suppnametxt.focus()">
<form name="suppmenu" action="<?php $_SERVER[PHP_SELF]?>" enctype="multipart/form-data" method="post">
  <table align="center" border="0">
  <tr>
    <td><table align="center">
        <tr>
          <th colspan="2">Insert new Supplier</th>
        </tr>
        <tr>
          <td>Supplier Name: *</td>
          <td><input type="text" name="suppnametxt" id="suppnametxt"/></td>
        </tr>
        <tr>
          <td>Phone:</td>
          <td><input type="text" name="phonetxt" id="phonetxt" maxlength="8" onKeyUp="checkphone()"/></td>
        </tr>
        <tr>
          <td>Mobile:</td>
          <td><input type="text" name="mobiletxt" id="mobiletxt" maxlength="8" onKeyUp="checkmobile()"/></td>
        </tr>
        <tr>
          <td>Address:</td>
          <td><input type="text" name="Addresstext" id="Addresstext"/></td>
        </tr>
                <tr>
          <td>Notes:</td>
          <td><input type="text" name="Notetext" id="Notetext"/></td>
        </tr>
        <tr>
          <td align="center" colspan="2"><input type="submit" name="submit" value="Save"></td>
        </tr>
      </table></td>

    <td><table align="center" border="1">
      <tr>
        <td align="center" colspan="7"> All Suppliers</td>
      </tr>
      <tr>
        <td>Name</td>
        <td>Phone</td>
        <td>Mobile</td>
        <td>Address</td>
        <td>Notes</td>
        <td>Edit</td>
        <td>Delete</td>
      </tr>
      <?php
	  //Pour les pagination du page
	  $messagesParPage=16; //Nous allons afficher 5 messages par page.

//Une connexion SQL doit être ouverte avant cette ligne...
$retour_total=mysql_query("SELECT COUNT(*) AS total FROM supplier "); //Nous récupérons le contenu de la requête dans $retour_total
$donnees_total=mysql_fetch_assoc($retour_total); //On range retour sous la forme d'un tableau.
$total=$donnees_total['total']; //On récupère le total pour le placer dans la variable $total.

//Nous allons maintenant compter le nombre de pages.
$nombreDePages=ceil($total/$messagesParPage);

if(isset($_GET['page'])) // Si la variable $_GET['page'] existe...
{
     $pageActuelle=intval($_GET['page']);
     
     if($pageActuelle>$nombreDePages) // Si la valeur de $pageActuelle (le numéro de la page) est plus grande que $nombreDePages...
     {
          $pageActuelle=$nombreDePages;
     }
}
else // Sinon
{
     $pageActuelle=1; // La page actuelle est la n°1    
}

	 $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire
    
// La requête sql pour récupérer les messages de la page actuelle.
//$query="SELECT * FROM  `supplier` ORDER BY  `supplier`.`supplier_name` ASC 
//LIMIT ".$premiereEntree.", ".$messagesParPage." ";
//echo "newww: ".$query;
//exit;
$ReadSupplier=mysql_query("SELECT * 
FROM  `supplier` 
ORDER BY  `supplier`.`supplier_name` ASC 
LIMIT ".$premiereEntree.", ".$messagesParPage." ");

	//	$description = substr($donnees_messages[news_desc],0,300)."...";
     //Je vais afficher les messages dans des petits tableaux. C'est à vous d'adapter pour votre design...
     //De plus j'ajoute aussi un nl2br pour prendre en compte les sauts à la ligne dans le message.     

	while($GetAllSuppliers=mysql_fetch_array($ReadSupplier)){
		echo "<tr>";
		echo "<td>".$GetAllSuppliers['supplier_name']."</td>";
		echo "<td>".$GetAllSuppliers['supplier_phone']."</td>";
		echo "<td>".$GetAllSuppliers['supplier_mobile']."</td>";
		echo "<td>".$GetAllSuppliers['supplier_address']."</td>";
		echo "<td>".$GetAllSuppliers['supplier_notes']."</td>";
		echo "<td>";
		?>
        <a href="edit_supplier.php?id=<?php echo $GetAllSuppliers['supplier_id'];?>"><img width="35" height="26" src="images/edit.jpg"  /></a>
        <td><a href="delete_supplier.php?id=<?php echo $GetAllSuppliers['supplier_id'];?>"><img width="35" height="26" src="images/b_drop.png"  /></a> </td>
  
        <?php
		echo "</td>";
		echo "</tr>";
	} // End while
?>
    </table>
      <?php
//pagination
echo '<p align="center">Page : '; //Pour l'affichage, on centre la liste des pages
for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
{
     //On va faire notre condition
     if($i==$pageActuelle) //Si il s'agit de la page actuelle...
     {
         echo ' [ '.$i.' ] '; 
     } //end if	
     else //Sinon...
     {
          echo ' <a href="insert_supplier.php?page='.$i.'">'.$i.'</a> ';
     }//end else
}// end for
echo '</p>';
?>
    
    
    
    </td>
      </tr></table>
</form>
<script language="JavaScript" type="text/javascript">
var frmvalidator = new Validator("suppmenu");
frmvalidator.addValidation("suppnametxt","req","Please enter an article");
</script>
</body>
</html>