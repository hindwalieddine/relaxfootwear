<?php 
require_once("include/function.php");
login_user_pass_defined("super","super");
?>
