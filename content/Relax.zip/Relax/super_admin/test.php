<?php session_start() ?>
<?php
ob_start();
include("include/function.php");
check_login_superadmin(); 
require_once("../config/connect.php");
include_once("include/menu.php");
$articleid=$_POST['articletxt'];
$arcticle_purch_price=$_POST['purchasetxt'];
$article_sale_price=$_POST['salepricetxt'];
$after_solde_price=$_POST['aftersalepricetxt'];
$supp_name=$_POST['article_supp_name'];

// Check to see if the article is already inserted or not!
/*
$result=mysql_query($Checkifexist="SELECT COUNT(*) as nb FROM `article` WHERE `article_id`='$articleid'");
while($res=mysql_fetch_array($result)){
	if($res['$nb']==1){
		echo "ttttt";
		?>
		<script language="javascript">
	//alert("You already create this article ");
	//location = 'insert_article.php';
	</script>
    <?php
	exit;
		}
		

}
*/
$Getsupid=mysql_query("SELECT * 
FROM  `supplier`
WHERE  `supplier_name` LIKE CONVERT( _utf8 '$supp_name'
USING latin1 ) 
COLLATE latin1_swedish_ci
LIMIT 0 , 30");
while($result=mysql_fetch_array($Getsupid)){
	$sup_id=$result['supplier_id'];

}
//echo $articleid;echo "<br>";echo $arcticle_purch_price;echo "<br>";echo $article_sale_price;echo "<br>";echo $after_solde_price;echo "<br>";

//Insert the new article into the database!
$Insertintoarticle="INSERT INTO  `article` (  `article_id` ,  `article_pur_price` ,  `article_sale_price` ,  `article_after_solde_price` ,  `article_supplier_id` ) VALUES ('$articleid', '$arcticle_purch_price' , '$article_sale_price' , '$after_solde_price' , '$sup_id');";
echo $query2;
@mysql_query($Insertintoarticle);

//header('Location:insert_article.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript" src="fckeditor/fckeditor.js">


</script>
<body>
<form name="menu1" action="<?php $_SERVER[PHP_SELF]?>" enctype="multipart/form-data" method="post">
  <table align="center" border="0">
  <tr>
    <td><table align="center">
        <tr>
          <th>Insert new Article</th>
        </tr>
        <tr>
          <td>Article number: *</td>
          <td><input type="text" name="articletxt" id="articletxt"/></td>
        </tr>
        <tr>
          <td>Purchase price:*</td>
          <td><input type="text" name="purchasetxt" id="purchasetxt"/></td>
        </tr>
        <tr>
          <td>Sale price:*</td>
          <td><input type="text" name="salepricetxt" id="salepricetxt" /></td>
        </tr>
        <tr>
          <td>After solde price:</td>
          <td><input type="text" name="aftersalepricetxt" id="aftersalepricetxt"/></td>
        </tr>
        <?php
	$result=mysql_query("SELECT * FROM `supplier` ORDER BY supplier_name");
	//echo $query; echo "<br>";
    ?>
        <tr>
          <td>Supplier:*</td>
          <td><select name="article_supp_name">
              <?php
	while($getSupplier=mysql_fetch_array($result)){
	echo $getSupplier['supplier_name'];
		?>
              <option value="<?php echo $getSupplier['supplier_name'];?>"> <?php echo $getSupplier['supplier_name'];?> </option>
              <?php
    }
	?>
            </select>
          <td>
        </tr>
        <tr>
          <td align="center" colspan="2"><input type="submit" value="Save"></td>
        </tr>
      </table></td>
    <td><table align="center" border="1">
      <tr>
        <td align="center" colspan="7"> All Articles</td>
      </tr>
      <tr>
        <td>Article</td>
        <td>Purchase Price</td>
        <td>Sale Price</td>
        <td>After Sale Price</td>
        <td>Supplier Name</td>
        <td>Edit</td>
        <td>Delete</td>
      </tr>
      <?php
    $GetAllArticles=mysql_query("SELECT * 
FROM  `article` 
ORDER BY  `article`.`article_id` ASC 
LIMIT 0 , 30");
	while($GetArticles=mysql_fetch_array($GetAllArticles)){
		echo "<tr>";
		echo "<td>".$GetArticles['article_id']."</td>";
		echo "<td>".$GetArticles['article_pur_price']."</td>";
		echo "<td>".$GetArticles['article_sale_price']."</td>";
		echo "<td>".$GetArticles['article_after_solde_price']."</td>";
		echo "<td>".$GetArticles['article_supplier_id']."</td>";
		echo "<td>";
		?>
        <a href="edit_article.php?id=<?php echo $GetArticles[article_id];?>"><img width="35" height="26" src="images/edit.jpg"  /></a>
        <td><a href="delete_article.php?id=<?php echo $GetArticles[article_id];?>"><img width="35" height="26" src="images/b_drop.png"  /></a> </td>
  
        <?php
		echo "</td>";
		echo "</tr>";
	}
?>
    </table></td>
      </tr></table>
</form>
<script language="JavaScript" type="text/javascript">
var frmvalidator = new Validator("menu1");
frmvalidator.addValidation("articletxt","req","Please enter an article");
frmvalidator.addValidation("purchasetxt","req","Please enter the purchase price");
frmvalidator.addValidation("salepricetxt","req","Please enter a Sale price");
frmvalidator.addValidation("article_supp_name","req","Please choose a supplier")
</script>
</body>
</html>