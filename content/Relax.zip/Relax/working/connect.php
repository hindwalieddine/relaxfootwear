<?php
$host="localhost";
$user="admin";
$password="admin";
$db="relax";
mysql_connect(localhost,$user,$password);
@mysql_select_db($db) or die( "Unable to select database");
?>
