<?php
include_once("connect.php");

$id=$_GET['cID'];

if (isset($id)) {
$result=mysql_query("SELECT * FROM ajax_client WHERE clientID='$id'") or die("error: ".mysql_error());
while($plist=mysql_fetch_assoc($result)) {

$json = array(array('field' => 'firstname',
'value' => $plist[firstname]),
array('field' => 'lastname',
'value' => $plist[lastname]),
array('field' => 'address',
'value' => $plist[address]),
array('field' => 'zipCode',
'value' => $plist[zipCode]),
array('field' => 'city',
'value' => $plist[city]),
array('field' => 'country',
'value' => $plist[country]) //last item should have no comma
);
}
}
print json_encode($json);
?>